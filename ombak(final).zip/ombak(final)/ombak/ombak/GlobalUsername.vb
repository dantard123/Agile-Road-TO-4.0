﻿Imports System.IO
Module GlobalUsername
    Friend Globalstaffid As String
    Friend Globalstaffname As String
    Friend Globalstaffgender As String
    Friend Globalstaffposition As String
    Friend Globalstaffcontact As String
    Friend Globalstaffemail As String
    Friend Globalstaffaddress As String
    Friend Globalstaffic As String
    Friend Globalusername2 As String
    Friend Globalpassword As String
End Module
