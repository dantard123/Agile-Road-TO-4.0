﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Payment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Payment))
        Me.lblValid = New System.Windows.Forms.Label()
        Me.txtMemberID = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtAmountTendered = New System.Windows.Forms.TextBox()
        Me.lblChangeDue = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnItem53 = New System.Windows.Forms.Button()
        Me.btnItem51 = New System.Windows.Forms.Button()
        Me.btnItem50 = New System.Windows.Forms.Button()
        Me.btnItem49 = New System.Windows.Forms.Button()
        Me.btnItem48 = New System.Windows.Forms.Button()
        Me.btnItem52 = New System.Windows.Forms.Button()
        Me.btnItem47 = New System.Windows.Forms.Button()
        Me.btnItem46 = New System.Windows.Forms.Button()
        Me.btnItem45 = New System.Windows.Forms.Button()
        Me.btnItem44 = New System.Windows.Forms.Button()
        Me.btnItem43 = New System.Windows.Forms.Button()
        Me.btnItem42 = New System.Windows.Forms.Button()
        Me.btnItem41 = New System.Windows.Forms.Button()
        Me.btnItem40 = New System.Windows.Forms.Button()
        Me.btnItem39 = New System.Windows.Forms.Button()
        Me.btnItem38 = New System.Windows.Forms.Button()
        Me.btnItem37 = New System.Windows.Forms.Button()
        Me.btnItem36 = New System.Windows.Forms.Button()
        Me.btnItem35 = New System.Windows.Forms.Button()
        Me.btnItem34 = New System.Windows.Forms.Button()
        Me.btnItem33 = New System.Windows.Forms.Button()
        Me.btnItem32 = New System.Windows.Forms.Button()
        Me.btnItem31 = New System.Windows.Forms.Button()
        Me.btnItem30 = New System.Windows.Forms.Button()
        Me.btnItem29 = New System.Windows.Forms.Button()
        Me.btnItem28 = New System.Windows.Forms.Button()
        Me.btnItem27 = New System.Windows.Forms.Button()
        Me.btnItem26 = New System.Windows.Forms.Button()
        Me.btnItem25 = New System.Windows.Forms.Button()
        Me.btnItem24 = New System.Windows.Forms.Button()
        Me.btnItem23 = New System.Windows.Forms.Button()
        Me.btnItem22 = New System.Windows.Forms.Button()
        Me.btnItem21 = New System.Windows.Forms.Button()
        Me.btnItem20 = New System.Windows.Forms.Button()
        Me.btnItem19 = New System.Windows.Forms.Button()
        Me.btnItem18 = New System.Windows.Forms.Button()
        Me.btnItem17 = New System.Windows.Forms.Button()
        Me.btnItem16 = New System.Windows.Forms.Button()
        Me.btnItem15 = New System.Windows.Forms.Button()
        Me.btnItem14 = New System.Windows.Forms.Button()
        Me.btnItem13 = New System.Windows.Forms.Button()
        Me.btnItem12 = New System.Windows.Forms.Button()
        Me.btnItem11 = New System.Windows.Forms.Button()
        Me.btnItem10 = New System.Windows.Forms.Button()
        Me.btnItem9 = New System.Windows.Forms.Button()
        Me.btnItem8 = New System.Windows.Forms.Button()
        Me.btnItem7 = New System.Windows.Forms.Button()
        Me.btnItem6 = New System.Windows.Forms.Button()
        Me.btnItem5 = New System.Windows.Forms.Button()
        Me.btnItem4 = New System.Windows.Forms.Button()
        Me.btnItem3 = New System.Windows.Forms.Button()
        Me.btnItem2 = New System.Windows.Forms.Button()
        Me.btnItem1 = New System.Windows.Forms.Button()
        Me.btnItem0 = New System.Windows.Forms.Button()
        Me.btnOther = New System.Windows.Forms.Button()
        Me.btnDailySupplies = New System.Windows.Forms.Button()
        Me.DGV = New System.Windows.Forms.DataGridView()
        Me.QuantityDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.UnitPriceDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SubTotalDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PaymentTempBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DatabaseDataSet = New ombak.DatabaseDataSet()
        Me.PaymentTempTableAdapter = New ombak.DatabaseDataSetTableAdapters.PaymentTempTableAdapter()
        Me.lblStaffName = New System.Windows.Forms.Label()
        Me.lblStaffID = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.profilepicture = New System.Windows.Forms.PictureBox()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnBill = New System.Windows.Forms.Button()
        Me.btnAdmin = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnRM100 = New System.Windows.Forms.Button()
        Me.btnRM50 = New System.Windows.Forms.Button()
        Me.btnRM20 = New System.Windows.Forms.Button()
        Me.btnRM10 = New System.Windows.Forms.Button()
        Me.btnRM5 = New System.Windows.Forms.Button()
        Me.btnRM1 = New System.Windows.Forms.Button()
        Me.btnMagazine = New System.Windows.Forms.Button()
        Me.btnSnack = New System.Windows.Forms.Button()
        Me.btnFood = New System.Windows.Forms.Button()
        Me.btnBeverage = New System.Windows.Forms.Button()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        CType(Me.DGV, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PaymentTempBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DatabaseDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.profilepicture, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblValid
        '
        Me.lblValid.AutoSize = True
        Me.lblValid.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblValid.ForeColor = System.Drawing.Color.Yellow
        Me.lblValid.Location = New System.Drawing.Point(1264, 84)
        Me.lblValid.MinimumSize = New System.Drawing.Size(50, 0)
        Me.lblValid.Name = "lblValid"
        Me.lblValid.Size = New System.Drawing.Size(50, 13)
        Me.lblValid.TabIndex = 178
        '
        'txtMemberID
        '
        Me.txtMemberID.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Bold)
        Me.txtMemberID.Location = New System.Drawing.Point(1143, 74)
        Me.txtMemberID.Name = "txtMemberID"
        Me.txtMemberID.Size = New System.Drawing.Size(115, 30)
        Me.txtMemberID.TabIndex = 177
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label4.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Bold)
        Me.Label4.ForeColor = System.Drawing.Color.Aqua
        Me.Label4.Location = New System.Drawing.Point(1139, 49)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(119, 23)
        Me.Label4.TabIndex = 176
        Me.Label4.Text = "Member ID"
        '
        'txtAmountTendered
        '
        Me.txtAmountTendered.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtAmountTendered.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Bold)
        Me.txtAmountTendered.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.txtAmountTendered.Location = New System.Drawing.Point(924, 46)
        Me.txtAmountTendered.MinimumSize = New System.Drawing.Size(200, 4)
        Me.txtAmountTendered.Name = "txtAmountTendered"
        Me.txtAmountTendered.Size = New System.Drawing.Size(200, 30)
        Me.txtAmountTendered.TabIndex = 175
        '
        'lblChangeDue
        '
        Me.lblChangeDue.AutoSize = True
        Me.lblChangeDue.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblChangeDue.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Bold)
        Me.lblChangeDue.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblChangeDue.Location = New System.Drawing.Point(924, 81)
        Me.lblChangeDue.MinimumSize = New System.Drawing.Size(200, 0)
        Me.lblChangeDue.Name = "lblChangeDue"
        Me.lblChangeDue.Size = New System.Drawing.Size(200, 23)
        Me.lblChangeDue.TabIndex = 170
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label3.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(691, 81)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(232, 23)
        Me.Label3.TabIndex = 169
        Me.Label3.Text = "Change Due :            RM"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(691, 49)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(231, 23)
        Me.Label2.TabIndex = 168
        Me.Label2.Text = "Amount Tendered : RM"
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblTotal.Font = New System.Drawing.Font("Rockwell", 36.0!, System.Drawing.FontStyle.Bold)
        Me.lblTotal.ForeColor = System.Drawing.Color.Lime
        Me.lblTotal.Location = New System.Drawing.Point(1059, 108)
        Me.lblTotal.MinimumSize = New System.Drawing.Size(300, 50)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(300, 59)
        Me.lblTotal.TabIndex = 167
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.Font = New System.Drawing.Font("Rockwell", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Lime
        Me.Label1.Location = New System.Drawing.Point(681, 108)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(381, 59)
        Me.Label1.TabIndex = 166
        Me.Label1.Text = "Total Due : RM"
        '
        'btnItem53
        '
        Me.btnItem53.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem53.Location = New System.Drawing.Point(561, 594)
        Me.btnItem53.Name = "btnItem53"
        Me.btnItem53.Size = New System.Drawing.Size(111, 62)
        Me.btnItem53.TabIndex = 156
        Me.btnItem53.UseVisualStyleBackColor = True
        '
        'btnItem51
        '
        Me.btnItem51.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem51.Location = New System.Drawing.Point(341, 594)
        Me.btnItem51.Name = "btnItem51"
        Me.btnItem51.Size = New System.Drawing.Size(111, 62)
        Me.btnItem51.TabIndex = 154
        Me.btnItem51.UseVisualStyleBackColor = True
        '
        'btnItem50
        '
        Me.btnItem50.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem50.Location = New System.Drawing.Point(231, 594)
        Me.btnItem50.Name = "btnItem50"
        Me.btnItem50.Size = New System.Drawing.Size(111, 62)
        Me.btnItem50.TabIndex = 153
        Me.btnItem50.UseVisualStyleBackColor = True
        '
        'btnItem49
        '
        Me.btnItem49.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem49.Location = New System.Drawing.Point(121, 594)
        Me.btnItem49.Name = "btnItem49"
        Me.btnItem49.Size = New System.Drawing.Size(111, 62)
        Me.btnItem49.TabIndex = 152
        Me.btnItem49.UseVisualStyleBackColor = True
        '
        'btnItem48
        '
        Me.btnItem48.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem48.Location = New System.Drawing.Point(11, 594)
        Me.btnItem48.Name = "btnItem48"
        Me.btnItem48.Size = New System.Drawing.Size(111, 62)
        Me.btnItem48.TabIndex = 151
        Me.btnItem48.UseVisualStyleBackColor = True
        '
        'btnItem52
        '
        Me.btnItem52.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem52.Location = New System.Drawing.Point(451, 594)
        Me.btnItem52.Name = "btnItem52"
        Me.btnItem52.Size = New System.Drawing.Size(111, 62)
        Me.btnItem52.TabIndex = 155
        Me.btnItem52.UseVisualStyleBackColor = True
        '
        'btnItem47
        '
        Me.btnItem47.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem47.Location = New System.Drawing.Point(561, 533)
        Me.btnItem47.Name = "btnItem47"
        Me.btnItem47.Size = New System.Drawing.Size(111, 62)
        Me.btnItem47.TabIndex = 150
        Me.btnItem47.UseVisualStyleBackColor = True
        '
        'btnItem46
        '
        Me.btnItem46.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem46.Location = New System.Drawing.Point(451, 533)
        Me.btnItem46.Name = "btnItem46"
        Me.btnItem46.Size = New System.Drawing.Size(111, 62)
        Me.btnItem46.TabIndex = 149
        Me.btnItem46.UseVisualStyleBackColor = True
        '
        'btnItem45
        '
        Me.btnItem45.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem45.Location = New System.Drawing.Point(341, 533)
        Me.btnItem45.Name = "btnItem45"
        Me.btnItem45.Size = New System.Drawing.Size(111, 62)
        Me.btnItem45.TabIndex = 148
        Me.btnItem45.UseVisualStyleBackColor = True
        '
        'btnItem44
        '
        Me.btnItem44.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem44.Location = New System.Drawing.Point(231, 533)
        Me.btnItem44.Name = "btnItem44"
        Me.btnItem44.Size = New System.Drawing.Size(111, 62)
        Me.btnItem44.TabIndex = 147
        Me.btnItem44.UseVisualStyleBackColor = True
        '
        'btnItem43
        '
        Me.btnItem43.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem43.Location = New System.Drawing.Point(121, 533)
        Me.btnItem43.Name = "btnItem43"
        Me.btnItem43.Size = New System.Drawing.Size(111, 62)
        Me.btnItem43.TabIndex = 146
        Me.btnItem43.UseVisualStyleBackColor = True
        '
        'btnItem42
        '
        Me.btnItem42.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem42.Location = New System.Drawing.Point(11, 533)
        Me.btnItem42.Name = "btnItem42"
        Me.btnItem42.Size = New System.Drawing.Size(111, 62)
        Me.btnItem42.TabIndex = 145
        Me.btnItem42.UseVisualStyleBackColor = True
        '
        'btnItem41
        '
        Me.btnItem41.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem41.Location = New System.Drawing.Point(561, 472)
        Me.btnItem41.Name = "btnItem41"
        Me.btnItem41.Size = New System.Drawing.Size(111, 62)
        Me.btnItem41.TabIndex = 144
        Me.btnItem41.UseVisualStyleBackColor = True
        '
        'btnItem40
        '
        Me.btnItem40.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem40.Location = New System.Drawing.Point(451, 472)
        Me.btnItem40.Name = "btnItem40"
        Me.btnItem40.Size = New System.Drawing.Size(111, 62)
        Me.btnItem40.TabIndex = 143
        Me.btnItem40.UseVisualStyleBackColor = True
        '
        'btnItem39
        '
        Me.btnItem39.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem39.Location = New System.Drawing.Point(341, 472)
        Me.btnItem39.Name = "btnItem39"
        Me.btnItem39.Size = New System.Drawing.Size(111, 62)
        Me.btnItem39.TabIndex = 142
        Me.btnItem39.UseVisualStyleBackColor = True
        '
        'btnItem38
        '
        Me.btnItem38.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem38.Location = New System.Drawing.Point(231, 472)
        Me.btnItem38.Name = "btnItem38"
        Me.btnItem38.Size = New System.Drawing.Size(111, 62)
        Me.btnItem38.TabIndex = 141
        Me.btnItem38.UseVisualStyleBackColor = True
        '
        'btnItem37
        '
        Me.btnItem37.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem37.Location = New System.Drawing.Point(121, 472)
        Me.btnItem37.Name = "btnItem37"
        Me.btnItem37.Size = New System.Drawing.Size(111, 62)
        Me.btnItem37.TabIndex = 140
        Me.btnItem37.UseVisualStyleBackColor = True
        '
        'btnItem36
        '
        Me.btnItem36.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem36.Location = New System.Drawing.Point(11, 472)
        Me.btnItem36.Name = "btnItem36"
        Me.btnItem36.Size = New System.Drawing.Size(111, 62)
        Me.btnItem36.TabIndex = 139
        Me.btnItem36.UseVisualStyleBackColor = True
        '
        'btnItem35
        '
        Me.btnItem35.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem35.Location = New System.Drawing.Point(561, 411)
        Me.btnItem35.Name = "btnItem35"
        Me.btnItem35.Size = New System.Drawing.Size(111, 62)
        Me.btnItem35.TabIndex = 138
        Me.btnItem35.UseVisualStyleBackColor = True
        '
        'btnItem34
        '
        Me.btnItem34.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem34.Location = New System.Drawing.Point(451, 411)
        Me.btnItem34.Name = "btnItem34"
        Me.btnItem34.Size = New System.Drawing.Size(111, 62)
        Me.btnItem34.TabIndex = 137
        Me.btnItem34.UseVisualStyleBackColor = True
        '
        'btnItem33
        '
        Me.btnItem33.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem33.Location = New System.Drawing.Point(341, 411)
        Me.btnItem33.Name = "btnItem33"
        Me.btnItem33.Size = New System.Drawing.Size(111, 62)
        Me.btnItem33.TabIndex = 136
        Me.btnItem33.UseVisualStyleBackColor = True
        '
        'btnItem32
        '
        Me.btnItem32.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem32.Location = New System.Drawing.Point(231, 411)
        Me.btnItem32.Name = "btnItem32"
        Me.btnItem32.Size = New System.Drawing.Size(111, 62)
        Me.btnItem32.TabIndex = 135
        Me.btnItem32.UseVisualStyleBackColor = True
        '
        'btnItem31
        '
        Me.btnItem31.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem31.Location = New System.Drawing.Point(121, 411)
        Me.btnItem31.Name = "btnItem31"
        Me.btnItem31.Size = New System.Drawing.Size(111, 62)
        Me.btnItem31.TabIndex = 134
        Me.btnItem31.UseVisualStyleBackColor = True
        '
        'btnItem30
        '
        Me.btnItem30.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem30.Location = New System.Drawing.Point(11, 411)
        Me.btnItem30.Name = "btnItem30"
        Me.btnItem30.Size = New System.Drawing.Size(111, 62)
        Me.btnItem30.TabIndex = 133
        Me.btnItem30.UseVisualStyleBackColor = True
        '
        'btnItem29
        '
        Me.btnItem29.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem29.Location = New System.Drawing.Point(561, 350)
        Me.btnItem29.Name = "btnItem29"
        Me.btnItem29.Size = New System.Drawing.Size(111, 62)
        Me.btnItem29.TabIndex = 132
        Me.btnItem29.UseVisualStyleBackColor = True
        '
        'btnItem28
        '
        Me.btnItem28.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem28.Location = New System.Drawing.Point(451, 350)
        Me.btnItem28.Name = "btnItem28"
        Me.btnItem28.Size = New System.Drawing.Size(111, 62)
        Me.btnItem28.TabIndex = 131
        Me.btnItem28.UseVisualStyleBackColor = True
        '
        'btnItem27
        '
        Me.btnItem27.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem27.Location = New System.Drawing.Point(341, 350)
        Me.btnItem27.Name = "btnItem27"
        Me.btnItem27.Size = New System.Drawing.Size(111, 62)
        Me.btnItem27.TabIndex = 130
        Me.btnItem27.UseVisualStyleBackColor = True
        '
        'btnItem26
        '
        Me.btnItem26.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem26.Location = New System.Drawing.Point(231, 350)
        Me.btnItem26.Name = "btnItem26"
        Me.btnItem26.Size = New System.Drawing.Size(111, 62)
        Me.btnItem26.TabIndex = 129
        Me.btnItem26.UseVisualStyleBackColor = True
        '
        'btnItem25
        '
        Me.btnItem25.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem25.Location = New System.Drawing.Point(121, 350)
        Me.btnItem25.Name = "btnItem25"
        Me.btnItem25.Size = New System.Drawing.Size(111, 62)
        Me.btnItem25.TabIndex = 128
        Me.btnItem25.UseVisualStyleBackColor = True
        '
        'btnItem24
        '
        Me.btnItem24.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem24.Location = New System.Drawing.Point(11, 350)
        Me.btnItem24.Name = "btnItem24"
        Me.btnItem24.Size = New System.Drawing.Size(111, 62)
        Me.btnItem24.TabIndex = 127
        Me.btnItem24.UseVisualStyleBackColor = True
        '
        'btnItem23
        '
        Me.btnItem23.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem23.Location = New System.Drawing.Point(561, 289)
        Me.btnItem23.Name = "btnItem23"
        Me.btnItem23.Size = New System.Drawing.Size(111, 62)
        Me.btnItem23.TabIndex = 126
        Me.btnItem23.UseVisualStyleBackColor = True
        '
        'btnItem22
        '
        Me.btnItem22.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem22.Location = New System.Drawing.Point(451, 289)
        Me.btnItem22.Name = "btnItem22"
        Me.btnItem22.Size = New System.Drawing.Size(111, 62)
        Me.btnItem22.TabIndex = 125
        Me.btnItem22.UseVisualStyleBackColor = True
        '
        'btnItem21
        '
        Me.btnItem21.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem21.Location = New System.Drawing.Point(341, 289)
        Me.btnItem21.Name = "btnItem21"
        Me.btnItem21.Size = New System.Drawing.Size(111, 62)
        Me.btnItem21.TabIndex = 124
        Me.btnItem21.UseVisualStyleBackColor = True
        '
        'btnItem20
        '
        Me.btnItem20.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem20.Location = New System.Drawing.Point(231, 289)
        Me.btnItem20.Name = "btnItem20"
        Me.btnItem20.Size = New System.Drawing.Size(111, 62)
        Me.btnItem20.TabIndex = 123
        Me.btnItem20.UseVisualStyleBackColor = True
        '
        'btnItem19
        '
        Me.btnItem19.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem19.Location = New System.Drawing.Point(121, 289)
        Me.btnItem19.Name = "btnItem19"
        Me.btnItem19.Size = New System.Drawing.Size(111, 62)
        Me.btnItem19.TabIndex = 122
        Me.btnItem19.UseVisualStyleBackColor = True
        '
        'btnItem18
        '
        Me.btnItem18.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem18.Location = New System.Drawing.Point(11, 289)
        Me.btnItem18.Name = "btnItem18"
        Me.btnItem18.Size = New System.Drawing.Size(111, 62)
        Me.btnItem18.TabIndex = 121
        Me.btnItem18.UseVisualStyleBackColor = True
        '
        'btnItem17
        '
        Me.btnItem17.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem17.Location = New System.Drawing.Point(561, 228)
        Me.btnItem17.Name = "btnItem17"
        Me.btnItem17.Size = New System.Drawing.Size(111, 62)
        Me.btnItem17.TabIndex = 120
        Me.btnItem17.UseVisualStyleBackColor = True
        '
        'btnItem16
        '
        Me.btnItem16.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem16.Location = New System.Drawing.Point(451, 228)
        Me.btnItem16.Name = "btnItem16"
        Me.btnItem16.Size = New System.Drawing.Size(111, 62)
        Me.btnItem16.TabIndex = 119
        Me.btnItem16.UseVisualStyleBackColor = True
        '
        'btnItem15
        '
        Me.btnItem15.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem15.Location = New System.Drawing.Point(341, 228)
        Me.btnItem15.Name = "btnItem15"
        Me.btnItem15.Size = New System.Drawing.Size(111, 62)
        Me.btnItem15.TabIndex = 118
        Me.btnItem15.UseVisualStyleBackColor = True
        '
        'btnItem14
        '
        Me.btnItem14.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem14.Location = New System.Drawing.Point(231, 228)
        Me.btnItem14.Name = "btnItem14"
        Me.btnItem14.Size = New System.Drawing.Size(111, 62)
        Me.btnItem14.TabIndex = 117
        Me.btnItem14.UseVisualStyleBackColor = True
        '
        'btnItem13
        '
        Me.btnItem13.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem13.Location = New System.Drawing.Point(121, 228)
        Me.btnItem13.Name = "btnItem13"
        Me.btnItem13.Size = New System.Drawing.Size(111, 62)
        Me.btnItem13.TabIndex = 116
        Me.btnItem13.UseVisualStyleBackColor = True
        '
        'btnItem12
        '
        Me.btnItem12.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem12.Location = New System.Drawing.Point(11, 228)
        Me.btnItem12.Name = "btnItem12"
        Me.btnItem12.Size = New System.Drawing.Size(111, 62)
        Me.btnItem12.TabIndex = 115
        Me.btnItem12.UseVisualStyleBackColor = True
        '
        'btnItem11
        '
        Me.btnItem11.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem11.Location = New System.Drawing.Point(561, 167)
        Me.btnItem11.Name = "btnItem11"
        Me.btnItem11.Size = New System.Drawing.Size(111, 62)
        Me.btnItem11.TabIndex = 114
        Me.btnItem11.UseVisualStyleBackColor = True
        '
        'btnItem10
        '
        Me.btnItem10.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem10.Location = New System.Drawing.Point(451, 167)
        Me.btnItem10.Name = "btnItem10"
        Me.btnItem10.Size = New System.Drawing.Size(111, 62)
        Me.btnItem10.TabIndex = 113
        Me.btnItem10.UseVisualStyleBackColor = True
        '
        'btnItem9
        '
        Me.btnItem9.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem9.Location = New System.Drawing.Point(341, 167)
        Me.btnItem9.Name = "btnItem9"
        Me.btnItem9.Size = New System.Drawing.Size(111, 62)
        Me.btnItem9.TabIndex = 112
        Me.btnItem9.UseVisualStyleBackColor = True
        '
        'btnItem8
        '
        Me.btnItem8.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem8.Location = New System.Drawing.Point(231, 167)
        Me.btnItem8.Name = "btnItem8"
        Me.btnItem8.Size = New System.Drawing.Size(111, 62)
        Me.btnItem8.TabIndex = 111
        Me.btnItem8.UseVisualStyleBackColor = True
        '
        'btnItem7
        '
        Me.btnItem7.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem7.Location = New System.Drawing.Point(121, 167)
        Me.btnItem7.Name = "btnItem7"
        Me.btnItem7.Size = New System.Drawing.Size(111, 62)
        Me.btnItem7.TabIndex = 110
        Me.btnItem7.UseVisualStyleBackColor = True
        '
        'btnItem6
        '
        Me.btnItem6.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem6.Location = New System.Drawing.Point(11, 167)
        Me.btnItem6.Name = "btnItem6"
        Me.btnItem6.Size = New System.Drawing.Size(111, 62)
        Me.btnItem6.TabIndex = 109
        Me.btnItem6.UseVisualStyleBackColor = True
        '
        'btnItem5
        '
        Me.btnItem5.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem5.Location = New System.Drawing.Point(561, 106)
        Me.btnItem5.Name = "btnItem5"
        Me.btnItem5.Size = New System.Drawing.Size(111, 62)
        Me.btnItem5.TabIndex = 108
        Me.btnItem5.UseVisualStyleBackColor = True
        '
        'btnItem4
        '
        Me.btnItem4.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem4.Location = New System.Drawing.Point(451, 106)
        Me.btnItem4.Name = "btnItem4"
        Me.btnItem4.Size = New System.Drawing.Size(111, 62)
        Me.btnItem4.TabIndex = 107
        Me.btnItem4.UseVisualStyleBackColor = True
        '
        'btnItem3
        '
        Me.btnItem3.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem3.Location = New System.Drawing.Point(341, 106)
        Me.btnItem3.Name = "btnItem3"
        Me.btnItem3.Size = New System.Drawing.Size(111, 62)
        Me.btnItem3.TabIndex = 106
        Me.btnItem3.UseVisualStyleBackColor = True
        '
        'btnItem2
        '
        Me.btnItem2.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem2.Location = New System.Drawing.Point(231, 106)
        Me.btnItem2.Name = "btnItem2"
        Me.btnItem2.Size = New System.Drawing.Size(111, 62)
        Me.btnItem2.TabIndex = 105
        Me.btnItem2.UseVisualStyleBackColor = True
        '
        'btnItem1
        '
        Me.btnItem1.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem1.Location = New System.Drawing.Point(121, 106)
        Me.btnItem1.Name = "btnItem1"
        Me.btnItem1.Size = New System.Drawing.Size(111, 62)
        Me.btnItem1.TabIndex = 104
        Me.btnItem1.UseVisualStyleBackColor = True
        '
        'btnItem0
        '
        Me.btnItem0.Font = New System.Drawing.Font("Stencil", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem0.Location = New System.Drawing.Point(11, 106)
        Me.btnItem0.Name = "btnItem0"
        Me.btnItem0.Size = New System.Drawing.Size(111, 62)
        Me.btnItem0.TabIndex = 103
        Me.btnItem0.UseVisualStyleBackColor = True
        '
        'btnOther
        '
        Me.btnOther.Font = New System.Drawing.Font("Vivaldi", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOther.ForeColor = System.Drawing.Color.MediumVioletRed
        Me.btnOther.Location = New System.Drawing.Point(561, 38)
        Me.btnOther.Name = "btnOther"
        Me.btnOther.Size = New System.Drawing.Size(111, 62)
        Me.btnOther.TabIndex = 102
        Me.btnOther.Text = "&Other"
        Me.btnOther.UseVisualStyleBackColor = True
        '
        'btnDailySupplies
        '
        Me.btnDailySupplies.Font = New System.Drawing.Font("Vivaldi", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDailySupplies.ForeColor = System.Drawing.Color.MediumVioletRed
        Me.btnDailySupplies.Location = New System.Drawing.Point(341, 38)
        Me.btnDailySupplies.Name = "btnDailySupplies"
        Me.btnDailySupplies.Size = New System.Drawing.Size(111, 62)
        Me.btnDailySupplies.TabIndex = 100
        Me.btnDailySupplies.Text = "&Daily Supplies"
        Me.btnDailySupplies.UseVisualStyleBackColor = True
        '
        'DGV
        '
        Me.DGV.AllowUserToAddRows = False
        Me.DGV.AllowUserToDeleteRows = False
        Me.DGV.AutoGenerateColumns = False
        Me.DGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGV.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.QuantityDataGridViewTextBoxColumn, Me.ProductNameDataGridViewTextBoxColumn, Me.UnitPriceDataGridViewTextBoxColumn, Me.SubTotalDataGridViewTextBoxColumn})
        Me.DGV.DataSource = Me.PaymentTempBindingSource
        Me.DGV.Location = New System.Drawing.Point(679, 275)
        Me.DGV.Name = "DGV"
        Me.DGV.Size = New System.Drawing.Size(679, 391)
        Me.DGV.TabIndex = 179
        '
        'QuantityDataGridViewTextBoxColumn
        '
        Me.QuantityDataGridViewTextBoxColumn.DataPropertyName = "Quantity"
        Me.QuantityDataGridViewTextBoxColumn.HeaderText = "Quantity"
        Me.QuantityDataGridViewTextBoxColumn.Name = "QuantityDataGridViewTextBoxColumn"
        Me.QuantityDataGridViewTextBoxColumn.ReadOnly = True
        '
        'ProductNameDataGridViewTextBoxColumn
        '
        Me.ProductNameDataGridViewTextBoxColumn.DataPropertyName = "ProductName"
        Me.ProductNameDataGridViewTextBoxColumn.HeaderText = "Product Name"
        Me.ProductNameDataGridViewTextBoxColumn.Name = "ProductNameDataGridViewTextBoxColumn"
        Me.ProductNameDataGridViewTextBoxColumn.ReadOnly = True
        Me.ProductNameDataGridViewTextBoxColumn.Width = 217
        '
        'UnitPriceDataGridViewTextBoxColumn
        '
        Me.UnitPriceDataGridViewTextBoxColumn.DataPropertyName = "UnitPrice"
        Me.UnitPriceDataGridViewTextBoxColumn.HeaderText = "Unit Price"
        Me.UnitPriceDataGridViewTextBoxColumn.Name = "UnitPriceDataGridViewTextBoxColumn"
        Me.UnitPriceDataGridViewTextBoxColumn.ReadOnly = True
        Me.UnitPriceDataGridViewTextBoxColumn.Width = 160
        '
        'SubTotalDataGridViewTextBoxColumn
        '
        Me.SubTotalDataGridViewTextBoxColumn.DataPropertyName = "SubTotal"
        Me.SubTotalDataGridViewTextBoxColumn.HeaderText = "Sub Total"
        Me.SubTotalDataGridViewTextBoxColumn.Name = "SubTotalDataGridViewTextBoxColumn"
        Me.SubTotalDataGridViewTextBoxColumn.ReadOnly = True
        Me.SubTotalDataGridViewTextBoxColumn.Width = 160
        '
        'PaymentTempBindingSource
        '
        Me.PaymentTempBindingSource.DataMember = "PaymentTemp"
        Me.PaymentTempBindingSource.DataSource = Me.DatabaseDataSet
        '
        'DatabaseDataSet
        '
        Me.DatabaseDataSet.DataSetName = "DatabaseDataSet"
        Me.DatabaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'PaymentTempTableAdapter
        '
        Me.PaymentTempTableAdapter.ClearBeforeFill = True
        '
        'lblStaffName
        '
        Me.lblStaffName.AutoSize = True
        Me.lblStaffName.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.lblStaffName.Location = New System.Drawing.Point(317, 709)
        Me.lblStaffName.Name = "lblStaffName"
        Me.lblStaffName.Size = New System.Drawing.Size(0, 26)
        Me.lblStaffName.TabIndex = 97
        '
        'lblStaffID
        '
        Me.lblStaffID.AutoSize = True
        Me.lblStaffID.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.lblStaffID.Location = New System.Drawing.Point(317, 672)
        Me.lblStaffID.Name = "lblStaffID"
        Me.lblStaffID.Size = New System.Drawing.Size(0, 26)
        Me.lblStaffID.TabIndex = 95
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label45.Location = New System.Drawing.Point(162, 709)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(140, 26)
        Me.Label45.TabIndex = 93
        Me.Label45.Text = "Staff Name : "
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label46.Location = New System.Drawing.Point(199, 672)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(103, 26)
        Me.Label46.TabIndex = 92
        Me.Label46.Text = "Staff ID : "
        '
        'profilepicture
        '
        Me.profilepicture.Location = New System.Drawing.Point(53, 659)
        Me.profilepicture.Name = "profilepicture"
        Me.profilepicture.Size = New System.Drawing.Size(94, 88)
        Me.profilepicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.profilepicture.TabIndex = 180
        Me.profilepicture.TabStop = False
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Image = CType(resources.GetObject("btnExit.Image"), System.Drawing.Image)
        Me.btnExit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnExit.Location = New System.Drawing.Point(1177, 672)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(148, 63)
        Me.btnExit.TabIndex = 174
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.Image = Global.ombak.My.Resources.Resources.undo
        Me.btnReset.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnReset.Location = New System.Drawing.Point(1023, 672)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(148, 63)
        Me.btnReset.TabIndex = 173
        Me.btnReset.Text = "&Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnBill
        '
        Me.btnBill.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBill.Image = Global.ombak.My.Resources.Resources.bill
        Me.btnBill.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnBill.Location = New System.Drawing.Point(869, 672)
        Me.btnBill.Name = "btnBill"
        Me.btnBill.Size = New System.Drawing.Size(148, 63)
        Me.btnBill.TabIndex = 172
        Me.btnBill.Text = "&Bill"
        Me.btnBill.UseVisualStyleBackColor = True
        '
        'btnAdmin
        '
        Me.btnAdmin.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdmin.Image = Global.ombak.My.Resources.Resources.admin
        Me.btnAdmin.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAdmin.Location = New System.Drawing.Point(715, 672)
        Me.btnAdmin.Name = "btnAdmin"
        Me.btnAdmin.Size = New System.Drawing.Size(148, 63)
        Me.btnAdmin.TabIndex = 171
        Me.btnAdmin.Text = "&Admin Function"
        Me.btnAdmin.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnAdmin.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.PictureBox1.Location = New System.Drawing.Point(679, 36)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(680, 131)
        Me.PictureBox1.TabIndex = 165
        Me.PictureBox1.TabStop = False
        '
        'btnRM100
        '
        Me.btnRM100.Font = New System.Drawing.Font("Gill Sans Ultra Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRM100.ForeColor = System.Drawing.Color.Navy
        Me.btnRM100.Image = Global.ombak.My.Resources.Resources.RM100
        Me.btnRM100.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnRM100.Location = New System.Drawing.Point(1133, 222)
        Me.btnRM100.Name = "btnRM100"
        Me.btnRM100.Size = New System.Drawing.Size(226, 47)
        Me.btnRM100.TabIndex = 162
        Me.btnRM100.Text = "RM100"
        Me.btnRM100.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnRM100.UseVisualStyleBackColor = True
        '
        'btnRM50
        '
        Me.btnRM50.Font = New System.Drawing.Font("Gill Sans Ultra Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRM50.ForeColor = System.Drawing.Color.Navy
        Me.btnRM50.Image = Global.ombak.My.Resources.Resources.RM50
        Me.btnRM50.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnRM50.Location = New System.Drawing.Point(906, 222)
        Me.btnRM50.Name = "btnRM50"
        Me.btnRM50.Size = New System.Drawing.Size(226, 47)
        Me.btnRM50.TabIndex = 161
        Me.btnRM50.Text = "RM50"
        Me.btnRM50.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnRM50.UseVisualStyleBackColor = True
        '
        'btnRM20
        '
        Me.btnRM20.Font = New System.Drawing.Font("Gill Sans Ultra Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRM20.ForeColor = System.Drawing.Color.Navy
        Me.btnRM20.Image = Global.ombak.My.Resources.Resources.RM20
        Me.btnRM20.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnRM20.Location = New System.Drawing.Point(679, 222)
        Me.btnRM20.Name = "btnRM20"
        Me.btnRM20.Size = New System.Drawing.Size(226, 47)
        Me.btnRM20.TabIndex = 160
        Me.btnRM20.Text = "RM20"
        Me.btnRM20.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnRM20.UseVisualStyleBackColor = True
        '
        'btnRM10
        '
        Me.btnRM10.Font = New System.Drawing.Font("Gill Sans Ultra Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRM10.ForeColor = System.Drawing.Color.Navy
        Me.btnRM10.Image = Global.ombak.My.Resources.Resources.RM10
        Me.btnRM10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnRM10.Location = New System.Drawing.Point(1133, 175)
        Me.btnRM10.Name = "btnRM10"
        Me.btnRM10.Size = New System.Drawing.Size(226, 47)
        Me.btnRM10.TabIndex = 159
        Me.btnRM10.Text = "RM10"
        Me.btnRM10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnRM10.UseVisualStyleBackColor = True
        '
        'btnRM5
        '
        Me.btnRM5.Font = New System.Drawing.Font("Gill Sans Ultra Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRM5.ForeColor = System.Drawing.Color.Navy
        Me.btnRM5.Image = Global.ombak.My.Resources.Resources.RM5
        Me.btnRM5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnRM5.Location = New System.Drawing.Point(906, 175)
        Me.btnRM5.Name = "btnRM5"
        Me.btnRM5.Size = New System.Drawing.Size(226, 47)
        Me.btnRM5.TabIndex = 158
        Me.btnRM5.Text = "RM5"
        Me.btnRM5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnRM5.UseVisualStyleBackColor = True
        '
        'btnRM1
        '
        Me.btnRM1.Font = New System.Drawing.Font("Gill Sans Ultra Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRM1.ForeColor = System.Drawing.Color.Navy
        Me.btnRM1.Image = Global.ombak.My.Resources.Resources.RM1
        Me.btnRM1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnRM1.Location = New System.Drawing.Point(679, 175)
        Me.btnRM1.Name = "btnRM1"
        Me.btnRM1.Size = New System.Drawing.Size(226, 47)
        Me.btnRM1.TabIndex = 157
        Me.btnRM1.Text = "RM1"
        Me.btnRM1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnRM1.UseVisualStyleBackColor = True
        '
        'btnMagazine
        '
        Me.btnMagazine.Font = New System.Drawing.Font("Vivaldi", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMagazine.ForeColor = System.Drawing.Color.MediumVioletRed
        Me.btnMagazine.Image = Global.ombak.My.Resources.Resources.Magazine
        Me.btnMagazine.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnMagazine.Location = New System.Drawing.Point(451, 38)
        Me.btnMagazine.Name = "btnMagazine"
        Me.btnMagazine.Size = New System.Drawing.Size(111, 62)
        Me.btnMagazine.TabIndex = 101
        Me.btnMagazine.Text = "&Magazine"
        Me.btnMagazine.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnMagazine.UseVisualStyleBackColor = True
        '
        'btnSnack
        '
        Me.btnSnack.Font = New System.Drawing.Font("Vivaldi", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSnack.ForeColor = System.Drawing.Color.MediumVioletRed
        Me.btnSnack.Image = Global.ombak.My.Resources.Resources.Snack
        Me.btnSnack.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSnack.Location = New System.Drawing.Point(231, 38)
        Me.btnSnack.Name = "btnSnack"
        Me.btnSnack.Size = New System.Drawing.Size(111, 62)
        Me.btnSnack.TabIndex = 99
        Me.btnSnack.Text = "&Snack"
        Me.btnSnack.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSnack.UseVisualStyleBackColor = True
        '
        'btnFood
        '
        Me.btnFood.Font = New System.Drawing.Font("Vivaldi", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFood.ForeColor = System.Drawing.Color.MediumVioletRed
        Me.btnFood.Image = Global.ombak.My.Resources.Resources.Food
        Me.btnFood.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnFood.Location = New System.Drawing.Point(121, 38)
        Me.btnFood.Name = "btnFood"
        Me.btnFood.Size = New System.Drawing.Size(111, 62)
        Me.btnFood.TabIndex = 98
        Me.btnFood.Text = "&Food"
        Me.btnFood.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnFood.UseVisualStyleBackColor = True
        '
        'btnBeverage
        '
        Me.btnBeverage.Font = New System.Drawing.Font("Vivaldi", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBeverage.ForeColor = System.Drawing.Color.MediumVioletRed
        Me.btnBeverage.Image = Global.ombak.My.Resources.Resources.Beverage
        Me.btnBeverage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnBeverage.Location = New System.Drawing.Point(11, 38)
        Me.btnBeverage.Name = "btnBeverage"
        Me.btnBeverage.Size = New System.Drawing.Size(111, 62)
        Me.btnBeverage.TabIndex = 97
        Me.btnBeverage.Text = "B&everage"
        Me.btnBeverage.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnBeverage.UseVisualStyleBackColor = True
        '
        'PrintDocument1
        '
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'Payment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1370, 749)
        Me.Controls.Add(Me.profilepicture)
        Me.Controls.Add(Me.lblStaffName)
        Me.Controls.Add(Me.DGV)
        Me.Controls.Add(Me.lblValid)
        Me.Controls.Add(Me.lblStaffID)
        Me.Controls.Add(Me.txtMemberID)
        Me.Controls.Add(Me.Label45)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label46)
        Me.Controls.Add(Me.txtAmountTendered)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnBill)
        Me.Controls.Add(Me.btnAdmin)
        Me.Controls.Add(Me.lblChangeDue)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnRM100)
        Me.Controls.Add(Me.btnRM50)
        Me.Controls.Add(Me.btnRM20)
        Me.Controls.Add(Me.btnRM10)
        Me.Controls.Add(Me.btnRM5)
        Me.Controls.Add(Me.btnRM1)
        Me.Controls.Add(Me.btnItem53)
        Me.Controls.Add(Me.btnItem51)
        Me.Controls.Add(Me.btnItem50)
        Me.Controls.Add(Me.btnItem49)
        Me.Controls.Add(Me.btnItem48)
        Me.Controls.Add(Me.btnItem52)
        Me.Controls.Add(Me.btnItem47)
        Me.Controls.Add(Me.btnItem46)
        Me.Controls.Add(Me.btnItem45)
        Me.Controls.Add(Me.btnItem44)
        Me.Controls.Add(Me.btnItem43)
        Me.Controls.Add(Me.btnItem42)
        Me.Controls.Add(Me.btnItem41)
        Me.Controls.Add(Me.btnItem40)
        Me.Controls.Add(Me.btnItem39)
        Me.Controls.Add(Me.btnItem38)
        Me.Controls.Add(Me.btnItem37)
        Me.Controls.Add(Me.btnItem36)
        Me.Controls.Add(Me.btnItem35)
        Me.Controls.Add(Me.btnItem34)
        Me.Controls.Add(Me.btnItem33)
        Me.Controls.Add(Me.btnItem32)
        Me.Controls.Add(Me.btnItem31)
        Me.Controls.Add(Me.btnItem30)
        Me.Controls.Add(Me.btnItem29)
        Me.Controls.Add(Me.btnItem28)
        Me.Controls.Add(Me.btnItem27)
        Me.Controls.Add(Me.btnItem26)
        Me.Controls.Add(Me.btnItem25)
        Me.Controls.Add(Me.btnItem24)
        Me.Controls.Add(Me.btnItem23)
        Me.Controls.Add(Me.btnItem22)
        Me.Controls.Add(Me.btnItem21)
        Me.Controls.Add(Me.btnItem20)
        Me.Controls.Add(Me.btnItem19)
        Me.Controls.Add(Me.btnItem18)
        Me.Controls.Add(Me.btnItem17)
        Me.Controls.Add(Me.btnItem16)
        Me.Controls.Add(Me.btnItem15)
        Me.Controls.Add(Me.btnItem14)
        Me.Controls.Add(Me.btnItem13)
        Me.Controls.Add(Me.btnItem12)
        Me.Controls.Add(Me.btnItem11)
        Me.Controls.Add(Me.btnItem10)
        Me.Controls.Add(Me.btnItem9)
        Me.Controls.Add(Me.btnItem8)
        Me.Controls.Add(Me.btnItem7)
        Me.Controls.Add(Me.btnItem6)
        Me.Controls.Add(Me.btnItem5)
        Me.Controls.Add(Me.btnItem4)
        Me.Controls.Add(Me.btnItem3)
        Me.Controls.Add(Me.btnItem2)
        Me.Controls.Add(Me.btnItem1)
        Me.Controls.Add(Me.btnItem0)
        Me.Controls.Add(Me.btnOther)
        Me.Controls.Add(Me.btnMagazine)
        Me.Controls.Add(Me.btnDailySupplies)
        Me.Controls.Add(Me.btnSnack)
        Me.Controls.Add(Me.btnFood)
        Me.Controls.Add(Me.btnBeverage)
        Me.Name = "Payment"
        Me.Text = "Payment"
        CType(Me.DGV, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PaymentTempBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DatabaseDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.profilepicture, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblValid As System.Windows.Forms.Label
    Friend WithEvents txtMemberID As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtAmountTendered As System.Windows.Forms.TextBox
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents btnBill As System.Windows.Forms.Button
    Friend WithEvents btnAdmin As System.Windows.Forms.Button
    Friend WithEvents lblChangeDue As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblTotal As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents btnRM100 As System.Windows.Forms.Button
    Friend WithEvents btnRM50 As System.Windows.Forms.Button
    Friend WithEvents btnRM20 As System.Windows.Forms.Button
    Friend WithEvents btnRM10 As System.Windows.Forms.Button
    Friend WithEvents btnRM5 As System.Windows.Forms.Button
    Friend WithEvents btnRM1 As System.Windows.Forms.Button
    Friend WithEvents btnItem53 As System.Windows.Forms.Button
    Friend WithEvents btnItem51 As System.Windows.Forms.Button
    Friend WithEvents btnItem50 As System.Windows.Forms.Button
    Friend WithEvents btnItem49 As System.Windows.Forms.Button
    Friend WithEvents btnItem48 As System.Windows.Forms.Button
    Friend WithEvents btnItem52 As System.Windows.Forms.Button
    Friend WithEvents btnItem47 As System.Windows.Forms.Button
    Friend WithEvents btnItem46 As System.Windows.Forms.Button
    Friend WithEvents btnItem45 As System.Windows.Forms.Button
    Friend WithEvents btnItem44 As System.Windows.Forms.Button
    Friend WithEvents btnItem43 As System.Windows.Forms.Button
    Friend WithEvents btnItem42 As System.Windows.Forms.Button
    Friend WithEvents btnItem41 As System.Windows.Forms.Button
    Friend WithEvents btnItem40 As System.Windows.Forms.Button
    Friend WithEvents btnItem39 As System.Windows.Forms.Button
    Friend WithEvents btnItem38 As System.Windows.Forms.Button
    Friend WithEvents btnItem37 As System.Windows.Forms.Button
    Friend WithEvents btnItem36 As System.Windows.Forms.Button
    Friend WithEvents btnItem35 As System.Windows.Forms.Button
    Friend WithEvents btnItem34 As System.Windows.Forms.Button
    Friend WithEvents btnItem33 As System.Windows.Forms.Button
    Friend WithEvents btnItem32 As System.Windows.Forms.Button
    Friend WithEvents btnItem31 As System.Windows.Forms.Button
    Friend WithEvents btnItem30 As System.Windows.Forms.Button
    Friend WithEvents btnItem29 As System.Windows.Forms.Button
    Friend WithEvents btnItem28 As System.Windows.Forms.Button
    Friend WithEvents btnItem27 As System.Windows.Forms.Button
    Friend WithEvents btnItem26 As System.Windows.Forms.Button
    Friend WithEvents btnItem25 As System.Windows.Forms.Button
    Friend WithEvents btnItem24 As System.Windows.Forms.Button
    Friend WithEvents btnItem23 As System.Windows.Forms.Button
    Friend WithEvents btnItem22 As System.Windows.Forms.Button
    Friend WithEvents btnItem21 As System.Windows.Forms.Button
    Friend WithEvents btnItem20 As System.Windows.Forms.Button
    Friend WithEvents btnItem19 As System.Windows.Forms.Button
    Friend WithEvents btnItem18 As System.Windows.Forms.Button
    Friend WithEvents btnItem17 As System.Windows.Forms.Button
    Friend WithEvents btnItem16 As System.Windows.Forms.Button
    Friend WithEvents btnItem15 As System.Windows.Forms.Button
    Friend WithEvents btnItem14 As System.Windows.Forms.Button
    Friend WithEvents btnItem13 As System.Windows.Forms.Button
    Friend WithEvents btnItem12 As System.Windows.Forms.Button
    Friend WithEvents btnItem11 As System.Windows.Forms.Button
    Friend WithEvents btnItem10 As System.Windows.Forms.Button
    Friend WithEvents btnItem9 As System.Windows.Forms.Button
    Friend WithEvents btnItem8 As System.Windows.Forms.Button
    Friend WithEvents btnItem7 As System.Windows.Forms.Button
    Friend WithEvents btnItem6 As System.Windows.Forms.Button
    Friend WithEvents btnItem5 As System.Windows.Forms.Button
    Friend WithEvents btnItem4 As System.Windows.Forms.Button
    Friend WithEvents btnItem3 As System.Windows.Forms.Button
    Friend WithEvents btnItem2 As System.Windows.Forms.Button
    Friend WithEvents btnItem1 As System.Windows.Forms.Button
    Friend WithEvents btnItem0 As System.Windows.Forms.Button
    Friend WithEvents btnOther As System.Windows.Forms.Button
    Friend WithEvents btnMagazine As System.Windows.Forms.Button
    Friend WithEvents btnDailySupplies As System.Windows.Forms.Button
    Friend WithEvents btnSnack As System.Windows.Forms.Button
    Friend WithEvents btnFood As System.Windows.Forms.Button
    Friend WithEvents btnBeverage As System.Windows.Forms.Button
    Friend WithEvents DGV As System.Windows.Forms.DataGridView
    Friend WithEvents DatabaseDataSet As ombak.DatabaseDataSet
    Friend WithEvents PaymentTempBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents PaymentTempTableAdapter As ombak.DatabaseDataSetTableAdapters.PaymentTempTableAdapter
    Friend WithEvents QuantityDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ProductNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents UnitPriceDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SubTotalDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents lblStaffName As System.Windows.Forms.Label
    Friend WithEvents lblStaffID As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents profilepicture As System.Windows.Forms.PictureBox
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents PrintPreviewDialog1 As System.Windows.Forms.PrintPreviewDialog
End Class
