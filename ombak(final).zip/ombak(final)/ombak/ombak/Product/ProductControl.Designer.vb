﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProductControl
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ProductControl))
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TabControl3 = New System.Windows.Forms.TabControl()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.DataGridView10 = New System.Windows.Forms.DataGridView()
        Me.txtQuantity10 = New System.Windows.Forms.TextBox()
        Me.btnReset10 = New System.Windows.Forms.Button()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.btnSearch10 = New System.Windows.Forms.Button()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.txtAddAmount = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtSupplierID11 = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.btnAdd11 = New System.Windows.Forms.Button()
        Me.txtQuantity11 = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.txtProductBrand11 = New System.Windows.Forms.TextBox()
        Me.txtProductName11 = New System.Windows.Forms.TextBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.txtCategory11 = New System.Windows.Forms.TextBox()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.txtUnitPrice11 = New System.Windows.Forms.TextBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.txtProductID11 = New System.Windows.Forms.TextBox()
        Me.btnReset11 = New System.Windows.Forms.Button()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.btnSearch11 = New System.Windows.Forms.Button()
        Me.deleteStock = New System.Windows.Forms.TabPage()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.txtSupplierID9 = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.btnDelete9 = New System.Windows.Forms.Button()
        Me.txtQuantity9 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtProductBrand9 = New System.Windows.Forms.TextBox()
        Me.txtCreateDate9 = New System.Windows.Forms.TextBox()
        Me.txtProductName9 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.txtCategory9 = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txtUnitPrice9 = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.txtProductID9 = New System.Windows.Forms.TextBox()
        Me.btnReset9 = New System.Windows.Forms.Button()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.btnSearch9 = New System.Windows.Forms.Button()
        Me.byCategory = New System.Windows.Forms.TabPage()
        Me.cboProductCategory4 = New System.Windows.Forms.ComboBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.DataGridView4 = New System.Windows.Forms.DataGridView()
        Me.btnSearch2 = New System.Windows.Forms.Button()
        Me.ByProductID = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtSupplierID2 = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtQuantity2 = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtProductBrand2 = New System.Windows.Forms.TextBox()
        Me.txtCreateDate2 = New System.Windows.Forms.TextBox()
        Me.txtProductName2 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtCategory2 = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtUnitPrice2 = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtProductID2 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.byName = New System.Windows.Forms.TabPage()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.txtProductName3 = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.bySupplierID = New System.Windows.Forms.TabPage()
        Me.DataGridView5 = New System.Windows.Forms.DataGridView()
        Me.btnSearch5 = New System.Windows.Forms.Button()
        Me.txtSupplierID5 = New System.Windows.Forms.TextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.viewProduct = New System.Windows.Forms.TabPage()
        Me.addProduct = New System.Windows.Forms.TabPage()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.cboSupplierID1 = New System.Windows.Forms.ComboBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.txtProductBrand1 = New System.Windows.Forms.TextBox()
        Me.txtProductID1 = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.cboCategory1 = New System.Windows.Forms.ComboBox()
        Me.btnReset0 = New System.Windows.Forms.Button()
        Me.btnAdd0 = New System.Windows.Forms.Button()
        Me.txtCreateDate1 = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtUnitPrice1 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtProductName1 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.editStock = New System.Windows.Forms.TabPage()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtSupplierID6 = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.btnUpdate6 = New System.Windows.Forms.Button()
        Me.txtQuantity6 = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtProductBrand6 = New System.Windows.Forms.TextBox()
        Me.txtCreateDate6 = New System.Windows.Forms.TextBox()
        Me.txtProductName6 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtCategory6 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtUnitPrice6 = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtProductID6 = New System.Windows.Forms.TextBox()
        Me.btnReset6 = New System.Windows.Forms.Button()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.btnSearch6 = New System.Windows.Forms.Button()
        Me.ProductModule = New System.Windows.Forms.TabControl()
        Me.cmsClear = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ClearToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OmbakDataSet = New ombak.ombakDataSet()
        Me.ProductBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ProductTableAdapter = New ombak.ombakDataSetTableAdapters.ProductTableAdapter()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.backButton = New System.Windows.Forms.PictureBox()
        Me.lblStaffID = New System.Windows.Forms.Label()
        Me.lblStaffName = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TabPage3.SuspendLayout()
        Me.TabControl3.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.DataGridView10, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.deleteStock.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.byCategory.SuspendLayout()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ByProductID.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.byName.SuspendLayout()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.bySupplierID.SuspendLayout()
        CType(Me.DataGridView5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.viewProduct.SuspendLayout()
        Me.addProduct.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.editStock.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.ProductModule.SuspendLayout()
        Me.cmsClear.SuspendLayout()
        CType(Me.OmbakDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ProductBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.backButton, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.TabControl3)
        Me.TabPage3.Location = New System.Drawing.Point(4, 34)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(1346, 502)
        Me.TabPage3.TabIndex = 4
        Me.TabPage3.Text = "Add On Product Quantity"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'TabControl3
        '
        Me.TabControl3.Controls.Add(Me.TabPage2)
        Me.TabControl3.Controls.Add(Me.TabPage5)
        Me.TabControl3.Location = New System.Drawing.Point(71, 24)
        Me.TabControl3.Name = "TabControl3"
        Me.TabControl3.Padding = New System.Drawing.Point(18, 3)
        Me.TabControl3.SelectedIndex = 0
        Me.TabControl3.Size = New System.Drawing.Size(1200, 475)
        Me.TabControl3.TabIndex = 2
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.DataGridView10)
        Me.TabPage2.Controls.Add(Me.txtQuantity10)
        Me.TabPage2.Controls.Add(Me.btnReset10)
        Me.TabPage2.Controls.Add(Me.Label45)
        Me.TabPage2.Controls.Add(Me.btnSearch10)
        Me.TabPage2.Location = New System.Drawing.Point(4, 34)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1192, 437)
        Me.TabPage2.TabIndex = 0
        Me.TabPage2.Text = "Check Product Quantity"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'DataGridView10
        '
        Me.DataGridView10.BackgroundColor = System.Drawing.SystemColors.ButtonFace
        Me.DataGridView10.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView10.GridColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.DataGridView10.Location = New System.Drawing.Point(0, 87)
        Me.DataGridView10.Name = "DataGridView10"
        Me.DataGridView10.Size = New System.Drawing.Size(1192, 350)
        Me.DataGridView10.TabIndex = 24
        '
        'txtQuantity10
        '
        Me.txtQuantity10.Location = New System.Drawing.Point(482, 28)
        Me.txtQuantity10.Name = "txtQuantity10"
        Me.txtQuantity10.Size = New System.Drawing.Size(210, 31)
        Me.txtQuantity10.TabIndex = 1
        '
        'btnReset10
        '
        Me.btnReset10.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset10.Location = New System.Drawing.Point(864, 26)
        Me.btnReset10.Name = "btnReset10"
        Me.btnReset10.Size = New System.Drawing.Size(160, 32)
        Me.btnReset10.TabIndex = 23
        Me.btnReset10.Text = "Reset"
        Me.btnReset10.UseVisualStyleBackColor = True
        '
        'Label45
        '
        Me.Label45.Location = New System.Drawing.Point(198, 29)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(278, 30)
        Me.Label45.TabIndex = 0
        Me.Label45.Text = "Quantity Amount to Check : "
        Me.Label45.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnSearch10
        '
        Me.btnSearch10.Location = New System.Drawing.Point(698, 26)
        Me.btnSearch10.Name = "btnSearch10"
        Me.btnSearch10.Size = New System.Drawing.Size(160, 32)
        Me.btnSearch10.TabIndex = 2
        Me.btnSearch10.Text = "Search"
        Me.btnSearch10.UseVisualStyleBackColor = True
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.GroupBox5)
        Me.TabPage5.Controls.Add(Me.txtProductID11)
        Me.TabPage5.Controls.Add(Me.btnReset11)
        Me.TabPage5.Controls.Add(Me.Label46)
        Me.TabPage5.Controls.Add(Me.btnSearch11)
        Me.TabPage5.Location = New System.Drawing.Point(4, 34)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(1192, 437)
        Me.TabPage5.TabIndex = 1
        Me.TabPage5.Text = "Restock"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.txtAddAmount)
        Me.GroupBox5.Controls.Add(Me.Label24)
        Me.GroupBox5.Controls.Add(Me.txtSupplierID11)
        Me.GroupBox5.Controls.Add(Me.Label12)
        Me.GroupBox5.Controls.Add(Me.btnAdd11)
        Me.GroupBox5.Controls.Add(Me.txtQuantity11)
        Me.GroupBox5.Controls.Add(Me.Label39)
        Me.GroupBox5.Controls.Add(Me.txtProductBrand11)
        Me.GroupBox5.Controls.Add(Me.txtProductName11)
        Me.GroupBox5.Controls.Add(Me.Label41)
        Me.GroupBox5.Controls.Add(Me.txtCategory11)
        Me.GroupBox5.Controls.Add(Me.Label42)
        Me.GroupBox5.Controls.Add(Me.Label43)
        Me.GroupBox5.Controls.Add(Me.txtUnitPrice11)
        Me.GroupBox5.Controls.Add(Me.Label44)
        Me.GroupBox5.Font = New System.Drawing.Font("Times New Roman", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(251, 79)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(746, 352)
        Me.GroupBox5.TabIndex = 27
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Product Details"
        '
        'txtAddAmount
        '
        Me.txtAddAmount.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAddAmount.Location = New System.Drawing.Point(358, 240)
        Me.txtAddAmount.Name = "txtAddAmount"
        Me.txtAddAmount.Size = New System.Drawing.Size(210, 32)
        Me.txtAddAmount.TabIndex = 27
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(132, 239)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(220, 30)
        Me.Label24.TabIndex = 26
        Me.Label24.Text = "Add Amount : "
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtSupplierID11
        '
        Me.txtSupplierID11.Enabled = False
        Me.txtSupplierID11.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSupplierID11.Location = New System.Drawing.Point(358, 278)
        Me.txtSupplierID11.Name = "txtSupplierID11"
        Me.txtSupplierID11.Size = New System.Drawing.Size(210, 32)
        Me.txtSupplierID11.TabIndex = 25
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(132, 277)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(220, 30)
        Me.Label12.TabIndex = 24
        Me.Label12.Text = "Supplier ID : "
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnAdd11
        '
        Me.btnAdd11.Enabled = False
        Me.btnAdd11.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd11.Location = New System.Drawing.Point(251, 316)
        Me.btnAdd11.Name = "btnAdd11"
        Me.btnAdd11.Size = New System.Drawing.Size(160, 32)
        Me.btnAdd11.TabIndex = 22
        Me.btnAdd11.Text = "Add Quantity"
        Me.btnAdd11.UseVisualStyleBackColor = True
        '
        'txtQuantity11
        '
        Me.txtQuantity11.Enabled = False
        Me.txtQuantity11.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtQuantity11.Location = New System.Drawing.Point(358, 202)
        Me.txtQuantity11.Name = "txtQuantity11"
        Me.txtQuantity11.Size = New System.Drawing.Size(210, 32)
        Me.txtQuantity11.TabIndex = 21
        '
        'Label39
        '
        Me.Label39.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(132, 201)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(220, 30)
        Me.Label39.TabIndex = 20
        Me.Label39.Text = "&Quantity Available : "
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtProductBrand11
        '
        Me.txtProductBrand11.Enabled = False
        Me.txtProductBrand11.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProductBrand11.Location = New System.Drawing.Point(358, 164)
        Me.txtProductBrand11.Name = "txtProductBrand11"
        Me.txtProductBrand11.Size = New System.Drawing.Size(210, 32)
        Me.txtProductBrand11.TabIndex = 17
        '
        'txtProductName11
        '
        Me.txtProductName11.BackColor = System.Drawing.Color.White
        Me.txtProductName11.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtProductName11.Enabled = False
        Me.txtProductName11.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProductName11.Location = New System.Drawing.Point(358, 50)
        Me.txtProductName11.Name = "txtProductName11"
        Me.txtProductName11.Size = New System.Drawing.Size(350, 25)
        Me.txtProductName11.TabIndex = 11
        '
        'Label41
        '
        Me.Label41.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(132, 49)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(220, 30)
        Me.Label41.TabIndex = 10
        Me.Label41.Text = "Product &Name : "
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtCategory11
        '
        Me.txtCategory11.Enabled = False
        Me.txtCategory11.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCategory11.Location = New System.Drawing.Point(358, 126)
        Me.txtCategory11.Name = "txtCategory11"
        Me.txtCategory11.Size = New System.Drawing.Size(210, 32)
        Me.txtCategory11.TabIndex = 15
        '
        'Label42
        '
        Me.Label42.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(132, 87)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(220, 30)
        Me.Label42.TabIndex = 12
        Me.Label42.Text = "&Unit Price : "
        Me.Label42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label43
        '
        Me.Label43.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(132, 163)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(220, 30)
        Me.Label43.TabIndex = 16
        Me.Label43.Text = "Product &Brand : "
        Me.Label43.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtUnitPrice11
        '
        Me.txtUnitPrice11.Enabled = False
        Me.txtUnitPrice11.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUnitPrice11.Location = New System.Drawing.Point(358, 88)
        Me.txtUnitPrice11.Name = "txtUnitPrice11"
        Me.txtUnitPrice11.Size = New System.Drawing.Size(210, 32)
        Me.txtUnitPrice11.TabIndex = 13
        '
        'Label44
        '
        Me.Label44.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(132, 125)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(220, 30)
        Me.Label44.TabIndex = 14
        Me.Label44.Text = "Product &Category :"
        Me.Label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtProductID11
        '
        Me.txtProductID11.Location = New System.Drawing.Point(437, 28)
        Me.txtProductID11.Name = "txtProductID11"
        Me.txtProductID11.Size = New System.Drawing.Size(210, 31)
        Me.txtProductID11.TabIndex = 25
        '
        'btnReset11
        '
        Me.btnReset11.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset11.Location = New System.Drawing.Point(819, 26)
        Me.btnReset11.Name = "btnReset11"
        Me.btnReset11.Size = New System.Drawing.Size(160, 32)
        Me.btnReset11.TabIndex = 28
        Me.btnReset11.Text = "Reset"
        Me.btnReset11.UseVisualStyleBackColor = True
        '
        'Label46
        '
        Me.Label46.Location = New System.Drawing.Point(211, 28)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(220, 30)
        Me.Label46.TabIndex = 24
        Me.Label46.Text = "Product &ID : "
        Me.Label46.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnSearch11
        '
        Me.btnSearch11.Location = New System.Drawing.Point(653, 28)
        Me.btnSearch11.Name = "btnSearch11"
        Me.btnSearch11.Size = New System.Drawing.Size(160, 32)
        Me.btnSearch11.TabIndex = 26
        Me.btnSearch11.Text = "Search"
        Me.btnSearch11.UseVisualStyleBackColor = True
        '
        'deleteStock
        '
        Me.deleteStock.Controls.Add(Me.GroupBox4)
        Me.deleteStock.Controls.Add(Me.txtProductID9)
        Me.deleteStock.Controls.Add(Me.btnReset9)
        Me.deleteStock.Controls.Add(Me.Label31)
        Me.deleteStock.Controls.Add(Me.btnSearch9)
        Me.deleteStock.Location = New System.Drawing.Point(4, 34)
        Me.deleteStock.Name = "deleteStock"
        Me.deleteStock.Size = New System.Drawing.Size(1346, 502)
        Me.deleteStock.TabIndex = 3
        Me.deleteStock.Text = "Delete Product"
        Me.deleteStock.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.txtSupplierID9)
        Me.GroupBox4.Controls.Add(Me.Label36)
        Me.GroupBox4.Controls.Add(Me.btnDelete9)
        Me.GroupBox4.Controls.Add(Me.txtQuantity9)
        Me.GroupBox4.Controls.Add(Me.Label6)
        Me.GroupBox4.Controls.Add(Me.txtProductBrand9)
        Me.GroupBox4.Controls.Add(Me.txtCreateDate9)
        Me.GroupBox4.Controls.Add(Me.txtProductName9)
        Me.GroupBox4.Controls.Add(Me.Label7)
        Me.GroupBox4.Controls.Add(Me.Label27)
        Me.GroupBox4.Controls.Add(Me.txtCategory9)
        Me.GroupBox4.Controls.Add(Me.Label28)
        Me.GroupBox4.Controls.Add(Me.Label29)
        Me.GroupBox4.Controls.Add(Me.txtUnitPrice9)
        Me.GroupBox4.Controls.Add(Me.Label30)
        Me.GroupBox4.Font = New System.Drawing.Font("Times New Roman", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(251, 79)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(746, 393)
        Me.GroupBox4.TabIndex = 7
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Product Details"
        '
        'txtSupplierID9
        '
        Me.txtSupplierID9.Enabled = False
        Me.txtSupplierID9.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSupplierID9.Location = New System.Drawing.Point(358, 278)
        Me.txtSupplierID9.Name = "txtSupplierID9"
        Me.txtSupplierID9.Size = New System.Drawing.Size(210, 32)
        Me.txtSupplierID9.TabIndex = 25
        '
        'Label36
        '
        Me.Label36.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(132, 277)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(220, 30)
        Me.Label36.TabIndex = 24
        Me.Label36.Text = "Supplier ID"
        Me.Label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnDelete9
        '
        Me.btnDelete9.Enabled = False
        Me.btnDelete9.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete9.Location = New System.Drawing.Point(251, 328)
        Me.btnDelete9.Name = "btnDelete9"
        Me.btnDelete9.Size = New System.Drawing.Size(160, 32)
        Me.btnDelete9.TabIndex = 22
        Me.btnDelete9.Text = "Delete"
        Me.btnDelete9.UseVisualStyleBackColor = True
        '
        'txtQuantity9
        '
        Me.txtQuantity9.Enabled = False
        Me.txtQuantity9.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtQuantity9.Location = New System.Drawing.Point(358, 240)
        Me.txtQuantity9.Name = "txtQuantity9"
        Me.txtQuantity9.Size = New System.Drawing.Size(210, 32)
        Me.txtQuantity9.TabIndex = 21
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(132, 239)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(220, 30)
        Me.Label6.TabIndex = 20
        Me.Label6.Text = "&Quantity Available : "
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtProductBrand9
        '
        Me.txtProductBrand9.Enabled = False
        Me.txtProductBrand9.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProductBrand9.Location = New System.Drawing.Point(358, 164)
        Me.txtProductBrand9.Name = "txtProductBrand9"
        Me.txtProductBrand9.Size = New System.Drawing.Size(210, 32)
        Me.txtProductBrand9.TabIndex = 17
        '
        'txtCreateDate9
        '
        Me.txtCreateDate9.Enabled = False
        Me.txtCreateDate9.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCreateDate9.Location = New System.Drawing.Point(358, 202)
        Me.txtCreateDate9.Name = "txtCreateDate9"
        Me.txtCreateDate9.Size = New System.Drawing.Size(210, 32)
        Me.txtCreateDate9.TabIndex = 19
        '
        'txtProductName9
        '
        Me.txtProductName9.BackColor = System.Drawing.Color.White
        Me.txtProductName9.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtProductName9.Enabled = False
        Me.txtProductName9.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProductName9.Location = New System.Drawing.Point(358, 50)
        Me.txtProductName9.Name = "txtProductName9"
        Me.txtProductName9.Size = New System.Drawing.Size(350, 25)
        Me.txtProductName9.TabIndex = 11
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(132, 201)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(220, 30)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "Create &Date : "
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label27
        '
        Me.Label27.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(132, 49)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(220, 30)
        Me.Label27.TabIndex = 10
        Me.Label27.Text = "Product &Name : "
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtCategory9
        '
        Me.txtCategory9.Enabled = False
        Me.txtCategory9.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCategory9.Location = New System.Drawing.Point(358, 126)
        Me.txtCategory9.Name = "txtCategory9"
        Me.txtCategory9.Size = New System.Drawing.Size(210, 32)
        Me.txtCategory9.TabIndex = 15
        '
        'Label28
        '
        Me.Label28.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(132, 87)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(220, 30)
        Me.Label28.TabIndex = 12
        Me.Label28.Text = "&Unit Price : "
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label29
        '
        Me.Label29.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(132, 163)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(220, 30)
        Me.Label29.TabIndex = 16
        Me.Label29.Text = "Product &Brand : "
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtUnitPrice9
        '
        Me.txtUnitPrice9.Enabled = False
        Me.txtUnitPrice9.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUnitPrice9.Location = New System.Drawing.Point(358, 88)
        Me.txtUnitPrice9.Name = "txtUnitPrice9"
        Me.txtUnitPrice9.Size = New System.Drawing.Size(210, 32)
        Me.txtUnitPrice9.TabIndex = 13
        '
        'Label30
        '
        Me.Label30.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(132, 125)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(220, 30)
        Me.Label30.TabIndex = 14
        Me.Label30.Text = "Product &Category :"
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtProductID9
        '
        Me.txtProductID9.Location = New System.Drawing.Point(437, 28)
        Me.txtProductID9.Name = "txtProductID9"
        Me.txtProductID9.Size = New System.Drawing.Size(210, 31)
        Me.txtProductID9.TabIndex = 5
        '
        'btnReset9
        '
        Me.btnReset9.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset9.Location = New System.Drawing.Point(819, 28)
        Me.btnReset9.Name = "btnReset9"
        Me.btnReset9.Size = New System.Drawing.Size(160, 32)
        Me.btnReset9.TabIndex = 23
        Me.btnReset9.Text = "Reset"
        Me.btnReset9.UseVisualStyleBackColor = True
        '
        'Label31
        '
        Me.Label31.Location = New System.Drawing.Point(211, 28)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(220, 30)
        Me.Label31.TabIndex = 4
        Me.Label31.Text = "Product &ID : "
        Me.Label31.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnSearch9
        '
        Me.btnSearch9.Location = New System.Drawing.Point(653, 28)
        Me.btnSearch9.Name = "btnSearch9"
        Me.btnSearch9.Size = New System.Drawing.Size(160, 32)
        Me.btnSearch9.TabIndex = 6
        Me.btnSearch9.Text = "Search"
        Me.btnSearch9.UseVisualStyleBackColor = True
        '
        'byCategory
        '
        Me.byCategory.Controls.Add(Me.cboProductCategory4)
        Me.byCategory.Controls.Add(Me.Label34)
        Me.byCategory.Controls.Add(Me.DataGridView4)
        Me.byCategory.Location = New System.Drawing.Point(4, 34)
        Me.byCategory.Name = "byCategory"
        Me.byCategory.Padding = New System.Windows.Forms.Padding(3)
        Me.byCategory.Size = New System.Drawing.Size(1192, 437)
        Me.byCategory.TabIndex = 1
        Me.byCategory.Text = "By Category"
        Me.byCategory.UseVisualStyleBackColor = True
        '
        'cboProductCategory4
        '
        Me.cboProductCategory4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboProductCategory4.FormattingEnabled = True
        Me.cboProductCategory4.Items.AddRange(New Object() {"Food", "Beverage", "Snack", "Magazine", "Daily Supplies"})
        Me.cboProductCategory4.Location = New System.Drawing.Point(522, 28)
        Me.cboProductCategory4.Name = "cboProductCategory4"
        Me.cboProductCategory4.Size = New System.Drawing.Size(210, 33)
        Me.cboProductCategory4.TabIndex = 25
        '
        'Label34
        '
        Me.Label34.Location = New System.Drawing.Point(296, 28)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(220, 30)
        Me.Label34.TabIndex = 22
        Me.Label34.Text = "Product Category : "
        Me.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'DataGridView4
        '
        Me.DataGridView4.AllowUserToAddRows = False
        Me.DataGridView4.AllowUserToDeleteRows = False
        Me.DataGridView4.BackgroundColor = System.Drawing.SystemColors.ButtonFace
        Me.DataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView4.GridColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.DataGridView4.Location = New System.Drawing.Point(0, 87)
        Me.DataGridView4.Name = "DataGridView4"
        Me.DataGridView4.ReadOnly = True
        Me.DataGridView4.Size = New System.Drawing.Size(1192, 350)
        Me.DataGridView4.TabIndex = 21
        '
        'btnSearch2
        '
        Me.btnSearch2.Location = New System.Drawing.Point(703, 28)
        Me.btnSearch2.Name = "btnSearch2"
        Me.btnSearch2.Size = New System.Drawing.Size(160, 32)
        Me.btnSearch2.TabIndex = 2
        Me.btnSearch2.Text = "Search"
        Me.btnSearch2.UseVisualStyleBackColor = True
        '
        'ByProductID
        '
        Me.ByProductID.Controls.Add(Me.GroupBox1)
        Me.ByProductID.Controls.Add(Me.txtProductID2)
        Me.ByProductID.Controls.Add(Me.Label9)
        Me.ByProductID.Controls.Add(Me.btnSearch2)
        Me.ByProductID.Location = New System.Drawing.Point(4, 34)
        Me.ByProductID.Name = "ByProductID"
        Me.ByProductID.Padding = New System.Windows.Forms.Padding(3)
        Me.ByProductID.Size = New System.Drawing.Size(1192, 437)
        Me.ByProductID.TabIndex = 0
        Me.ByProductID.Text = "By Product ID"
        Me.ByProductID.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtSupplierID2)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.txtQuantity2)
        Me.GroupBox1.Controls.Add(Me.Label25)
        Me.GroupBox1.Controls.Add(Me.txtProductBrand2)
        Me.GroupBox1.Controls.Add(Me.txtCreateDate2)
        Me.GroupBox1.Controls.Add(Me.txtProductName2)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label20)
        Me.GroupBox1.Controls.Add(Me.txtCategory2)
        Me.GroupBox1.Controls.Add(Me.Label19)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.txtUnitPrice2)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Font = New System.Drawing.Font("Times New Roman", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(251, 79)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(746, 334)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Product Details"
        '
        'txtSupplierID2
        '
        Me.txtSupplierID2.Enabled = False
        Me.txtSupplierID2.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSupplierID2.Location = New System.Drawing.Point(358, 278)
        Me.txtSupplierID2.Name = "txtSupplierID2"
        Me.txtSupplierID2.Size = New System.Drawing.Size(210, 32)
        Me.txtSupplierID2.TabIndex = 13
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(132, 277)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(220, 30)
        Me.Label10.TabIndex = 12
        Me.Label10.Text = "Supplier ID : "
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtQuantity2
        '
        Me.txtQuantity2.Enabled = False
        Me.txtQuantity2.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtQuantity2.Location = New System.Drawing.Point(358, 240)
        Me.txtQuantity2.Name = "txtQuantity2"
        Me.txtQuantity2.Size = New System.Drawing.Size(210, 32)
        Me.txtQuantity2.TabIndex = 11
        '
        'Label25
        '
        Me.Label25.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(132, 239)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(220, 30)
        Me.Label25.TabIndex = 10
        Me.Label25.Text = "&Quantity Available : "
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtProductBrand2
        '
        Me.txtProductBrand2.Enabled = False
        Me.txtProductBrand2.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProductBrand2.Location = New System.Drawing.Point(358, 164)
        Me.txtProductBrand2.Name = "txtProductBrand2"
        Me.txtProductBrand2.Size = New System.Drawing.Size(210, 32)
        Me.txtProductBrand2.TabIndex = 7
        '
        'txtCreateDate2
        '
        Me.txtCreateDate2.Enabled = False
        Me.txtCreateDate2.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCreateDate2.Location = New System.Drawing.Point(358, 202)
        Me.txtCreateDate2.Name = "txtCreateDate2"
        Me.txtCreateDate2.Size = New System.Drawing.Size(210, 32)
        Me.txtCreateDate2.TabIndex = 9
        '
        'txtProductName2
        '
        Me.txtProductName2.BackColor = System.Drawing.Color.White
        Me.txtProductName2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtProductName2.Enabled = False
        Me.txtProductName2.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProductName2.Location = New System.Drawing.Point(358, 50)
        Me.txtProductName2.Name = "txtProductName2"
        Me.txtProductName2.Size = New System.Drawing.Size(350, 25)
        Me.txtProductName2.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(132, 201)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(220, 30)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Create &Date : "
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(132, 49)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(220, 30)
        Me.Label20.TabIndex = 0
        Me.Label20.Text = "&Product Name : "
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtCategory2
        '
        Me.txtCategory2.Enabled = False
        Me.txtCategory2.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCategory2.Location = New System.Drawing.Point(358, 126)
        Me.txtCategory2.Name = "txtCategory2"
        Me.txtCategory2.Size = New System.Drawing.Size(210, 32)
        Me.txtCategory2.TabIndex = 5
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(132, 87)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(220, 30)
        Me.Label19.TabIndex = 2
        Me.Label19.Text = "&Unit Price : "
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label17
        '
        Me.Label17.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(132, 163)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(220, 30)
        Me.Label17.TabIndex = 6
        Me.Label17.Text = "Product &Brand : "
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtUnitPrice2
        '
        Me.txtUnitPrice2.Enabled = False
        Me.txtUnitPrice2.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUnitPrice2.Location = New System.Drawing.Point(358, 88)
        Me.txtUnitPrice2.Name = "txtUnitPrice2"
        Me.txtUnitPrice2.Size = New System.Drawing.Size(210, 32)
        Me.txtUnitPrice2.TabIndex = 3
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(132, 125)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(220, 30)
        Me.Label18.TabIndex = 4
        Me.Label18.Text = "Product &Category :"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtProductID2
        '
        Me.txtProductID2.Location = New System.Drawing.Point(487, 28)
        Me.txtProductID2.Name = "txtProductID2"
        Me.txtProductID2.Size = New System.Drawing.Size(210, 31)
        Me.txtProductID2.TabIndex = 1
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(261, 28)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(220, 30)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Product &ID : "
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.ByProductID)
        Me.TabControl1.Controls.Add(Me.byName)
        Me.TabControl1.Controls.Add(Me.byCategory)
        Me.TabControl1.Controls.Add(Me.bySupplierID)
        Me.TabControl1.Location = New System.Drawing.Point(71, 24)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.Padding = New System.Drawing.Point(18, 3)
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1200, 475)
        Me.TabControl1.TabIndex = 0
        '
        'byName
        '
        Me.byName.Controls.Add(Me.DataGridView3)
        Me.byName.Controls.Add(Me.txtProductName3)
        Me.byName.Controls.Add(Me.Label33)
        Me.byName.Location = New System.Drawing.Point(4, 34)
        Me.byName.Name = "byName"
        Me.byName.Size = New System.Drawing.Size(1192, 437)
        Me.byName.TabIndex = 3
        Me.byName.Text = "By Product Name"
        Me.byName.UseVisualStyleBackColor = True
        '
        'DataGridView3
        '
        Me.DataGridView3.AllowUserToAddRows = False
        Me.DataGridView3.AllowUserToDeleteRows = False
        Me.DataGridView3.BackgroundColor = System.Drawing.SystemColors.ButtonFace
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView3.DefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridView3.GridColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.DataGridView3.Location = New System.Drawing.Point(0, 87)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.ReadOnly = True
        Me.DataGridView3.Size = New System.Drawing.Size(1192, 350)
        Me.DataGridView3.TabIndex = 6
        '
        'txtProductName3
        '
        Me.txtProductName3.Location = New System.Drawing.Point(522, 28)
        Me.txtProductName3.Name = "txtProductName3"
        Me.txtProductName3.Size = New System.Drawing.Size(210, 31)
        Me.txtProductName3.TabIndex = 4
        '
        'Label33
        '
        Me.Label33.Location = New System.Drawing.Point(296, 28)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(220, 30)
        Me.Label33.TabIndex = 3
        Me.Label33.Text = "Product Name : "
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'bySupplierID
        '
        Me.bySupplierID.Controls.Add(Me.DataGridView5)
        Me.bySupplierID.Controls.Add(Me.btnSearch5)
        Me.bySupplierID.Controls.Add(Me.txtSupplierID5)
        Me.bySupplierID.Controls.Add(Me.Label37)
        Me.bySupplierID.Location = New System.Drawing.Point(4, 34)
        Me.bySupplierID.Name = "bySupplierID"
        Me.bySupplierID.Size = New System.Drawing.Size(1192, 437)
        Me.bySupplierID.TabIndex = 4
        Me.bySupplierID.Text = "By Supplier ID"
        Me.bySupplierID.UseVisualStyleBackColor = True
        '
        'DataGridView5
        '
        Me.DataGridView5.BackgroundColor = System.Drawing.SystemColors.ButtonFace
        Me.DataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView5.GridColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.DataGridView5.Location = New System.Drawing.Point(0, 87)
        Me.DataGridView5.Name = "DataGridView5"
        Me.DataGridView5.Size = New System.Drawing.Size(1192, 350)
        Me.DataGridView5.TabIndex = 29
        '
        'btnSearch5
        '
        Me.btnSearch5.Location = New System.Drawing.Point(703, 27)
        Me.btnSearch5.Name = "btnSearch5"
        Me.btnSearch5.Size = New System.Drawing.Size(160, 32)
        Me.btnSearch5.TabIndex = 28
        Me.btnSearch5.Text = "Search"
        Me.btnSearch5.UseVisualStyleBackColor = True
        '
        'txtSupplierID5
        '
        Me.txtSupplierID5.Location = New System.Drawing.Point(487, 28)
        Me.txtSupplierID5.Name = "txtSupplierID5"
        Me.txtSupplierID5.Size = New System.Drawing.Size(210, 31)
        Me.txtSupplierID5.TabIndex = 27
        '
        'Label37
        '
        Me.Label37.Location = New System.Drawing.Point(261, 28)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(220, 30)
        Me.Label37.TabIndex = 26
        Me.Label37.Text = "Supplier ID : "
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'viewProduct
        '
        Me.viewProduct.Controls.Add(Me.TabControl1)
        Me.viewProduct.Location = New System.Drawing.Point(4, 34)
        Me.viewProduct.Name = "viewProduct"
        Me.viewProduct.Padding = New System.Windows.Forms.Padding(3)
        Me.viewProduct.Size = New System.Drawing.Size(1346, 502)
        Me.viewProduct.TabIndex = 1
        Me.viewProduct.Text = "Display Product"
        Me.viewProduct.UseVisualStyleBackColor = True
        '
        'addProduct
        '
        Me.addProduct.Controls.Add(Me.GroupBox3)
        Me.addProduct.Location = New System.Drawing.Point(4, 34)
        Me.addProduct.Name = "addProduct"
        Me.addProduct.Padding = New System.Windows.Forms.Padding(3)
        Me.addProduct.Size = New System.Drawing.Size(1346, 502)
        Me.addProduct.TabIndex = 0
        Me.addProduct.Text = "Register Product"
        Me.addProduct.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.cboSupplierID1)
        Me.GroupBox3.Controls.Add(Me.Label38)
        Me.GroupBox3.Controls.Add(Me.txtProductBrand1)
        Me.GroupBox3.Controls.Add(Me.txtProductID1)
        Me.GroupBox3.Controls.Add(Me.Label32)
        Me.GroupBox3.Controls.Add(Me.cboCategory1)
        Me.GroupBox3.Controls.Add(Me.btnReset0)
        Me.GroupBox3.Controls.Add(Me.btnAdd0)
        Me.GroupBox3.Controls.Add(Me.txtCreateDate1)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.txtUnitPrice1)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.txtProductName1)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Font = New System.Drawing.Font("Times New Roman", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(288, 24)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(850, 420)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Register Product"
        '
        'cboSupplierID1
        '
        Me.cboSupplierID1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSupplierID1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboSupplierID1.FormattingEnabled = True
        Me.cboSupplierID1.Location = New System.Drawing.Point(431, 296)
        Me.cboSupplierID1.Name = "cboSupplierID1"
        Me.cboSupplierID1.Size = New System.Drawing.Size(210, 33)
        Me.cboSupplierID1.TabIndex = 16
        '
        'Label38
        '
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(205, 296)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(220, 30)
        Me.Label38.TabIndex = 15
        Me.Label38.Text = "Supplier ID :"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtProductBrand1
        '
        Me.txtProductBrand1.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProductBrand1.Location = New System.Drawing.Point(431, 221)
        Me.txtProductBrand1.Name = "txtProductBrand1"
        Me.txtProductBrand1.Size = New System.Drawing.Size(210, 32)
        Me.txtProductBrand1.TabIndex = 14
        '
        'txtProductID1
        '
        Me.txtProductID1.Enabled = False
        Me.txtProductID1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProductID1.Location = New System.Drawing.Point(431, 71)
        Me.txtProductID1.Name = "txtProductID1"
        Me.txtProductID1.Size = New System.Drawing.Size(210, 31)
        Me.txtProductID1.TabIndex = 1
        '
        'Label32
        '
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(205, 71)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(220, 30)
        Me.Label32.TabIndex = 0
        Me.Label32.Text = "Product &ID : "
        Me.Label32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboCategory1
        '
        Me.cboCategory1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCategory1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCategory1.FormattingEnabled = True
        Me.cboCategory1.Items.AddRange(New Object() {"Food", "Beverage", "Daily Supplies", "Magazines", "Other"})
        Me.cboCategory1.Location = New System.Drawing.Point(431, 182)
        Me.cboCategory1.Name = "cboCategory1"
        Me.cboCategory1.Size = New System.Drawing.Size(210, 33)
        Me.cboCategory1.TabIndex = 7
        '
        'btnReset0
        '
        Me.btnReset0.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset0.Location = New System.Drawing.Point(431, 356)
        Me.btnReset0.Name = "btnReset0"
        Me.btnReset0.Size = New System.Drawing.Size(90, 30)
        Me.btnReset0.TabIndex = 13
        Me.btnReset0.Text = "Reset"
        Me.btnReset0.UseVisualStyleBackColor = True
        '
        'btnAdd0
        '
        Me.btnAdd0.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd0.Location = New System.Drawing.Point(335, 356)
        Me.btnAdd0.Name = "btnAdd0"
        Me.btnAdd0.Size = New System.Drawing.Size(90, 30)
        Me.btnAdd0.TabIndex = 12
        Me.btnAdd0.Text = "Add"
        Me.btnAdd0.UseVisualStyleBackColor = True
        '
        'txtCreateDate1
        '
        Me.txtCreateDate1.Enabled = False
        Me.txtCreateDate1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCreateDate1.Location = New System.Drawing.Point(431, 259)
        Me.txtCreateDate1.Name = "txtCreateDate1"
        Me.txtCreateDate1.Size = New System.Drawing.Size(210, 31)
        Me.txtCreateDate1.TabIndex = 11
        '
        'Label16
        '
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(205, 259)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(220, 30)
        Me.Label16.TabIndex = 10
        Me.Label16.Text = "Create &Date : "
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label15
        '
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(205, 219)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(220, 30)
        Me.Label15.TabIndex = 8
        Me.Label15.Text = "Product &Brand : "
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtUnitPrice1
        '
        Me.txtUnitPrice1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUnitPrice1.Location = New System.Drawing.Point(431, 145)
        Me.txtUnitPrice1.Name = "txtUnitPrice1"
        Me.txtUnitPrice1.Size = New System.Drawing.Size(210, 31)
        Me.txtUnitPrice1.TabIndex = 5
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(205, 182)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(220, 30)
        Me.Label14.TabIndex = 6
        Me.Label14.Text = "Product &Category :"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(205, 145)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(220, 30)
        Me.Label13.TabIndex = 4
        Me.Label13.Text = "&Unit Price : "
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtProductName1
        '
        Me.txtProductName1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProductName1.Location = New System.Drawing.Point(431, 108)
        Me.txtProductName1.Name = "txtProductName1"
        Me.txtProductName1.Size = New System.Drawing.Size(210, 31)
        Me.txtProductName1.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(205, 108)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(220, 30)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "&Product Name : "
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'editStock
        '
        Me.editStock.Controls.Add(Me.TabControl2)
        Me.editStock.Location = New System.Drawing.Point(4, 34)
        Me.editStock.Name = "editStock"
        Me.editStock.Size = New System.Drawing.Size(1346, 502)
        Me.editStock.TabIndex = 2
        Me.editStock.Text = "Update Product Price"
        Me.editStock.UseVisualStyleBackColor = True
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage1)
        Me.TabControl2.Location = New System.Drawing.Point(71, 24)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.Padding = New System.Drawing.Point(18, 3)
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(1200, 475)
        Me.TabControl2.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Controls.Add(Me.txtProductID6)
        Me.TabPage1.Controls.Add(Me.btnReset6)
        Me.TabPage1.Controls.Add(Me.Label23)
        Me.TabPage1.Controls.Add(Me.btnSearch6)
        Me.TabPage1.Location = New System.Drawing.Point(4, 34)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1192, 437)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "By Product ID"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtSupplierID6)
        Me.GroupBox2.Controls.Add(Me.Label35)
        Me.GroupBox2.Controls.Add(Me.btnUpdate6)
        Me.GroupBox2.Controls.Add(Me.txtQuantity6)
        Me.GroupBox2.Controls.Add(Me.Label26)
        Me.GroupBox2.Controls.Add(Me.txtProductBrand6)
        Me.GroupBox2.Controls.Add(Me.txtCreateDate6)
        Me.GroupBox2.Controls.Add(Me.txtProductName6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.txtCategory6)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label21)
        Me.GroupBox2.Controls.Add(Me.txtUnitPrice6)
        Me.GroupBox2.Controls.Add(Me.Label22)
        Me.GroupBox2.Font = New System.Drawing.Font("Times New Roman", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(251, 79)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(746, 352)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Product Details"
        '
        'txtSupplierID6
        '
        Me.txtSupplierID6.Enabled = False
        Me.txtSupplierID6.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSupplierID6.Location = New System.Drawing.Point(358, 278)
        Me.txtSupplierID6.Name = "txtSupplierID6"
        Me.txtSupplierID6.Size = New System.Drawing.Size(210, 32)
        Me.txtSupplierID6.TabIndex = 25
        '
        'Label35
        '
        Me.Label35.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(132, 277)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(220, 30)
        Me.Label35.TabIndex = 24
        Me.Label35.Text = "Supplier ID : "
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnUpdate6
        '
        Me.btnUpdate6.Enabled = False
        Me.btnUpdate6.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdate6.Location = New System.Drawing.Point(251, 316)
        Me.btnUpdate6.Name = "btnUpdate6"
        Me.btnUpdate6.Size = New System.Drawing.Size(160, 32)
        Me.btnUpdate6.TabIndex = 22
        Me.btnUpdate6.Text = "Update"
        Me.btnUpdate6.UseVisualStyleBackColor = True
        '
        'txtQuantity6
        '
        Me.txtQuantity6.Enabled = False
        Me.txtQuantity6.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtQuantity6.Location = New System.Drawing.Point(358, 240)
        Me.txtQuantity6.Name = "txtQuantity6"
        Me.txtQuantity6.Size = New System.Drawing.Size(210, 32)
        Me.txtQuantity6.TabIndex = 21
        '
        'Label26
        '
        Me.Label26.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(132, 239)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(220, 30)
        Me.Label26.TabIndex = 20
        Me.Label26.Text = "&Quantity Available : "
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtProductBrand6
        '
        Me.txtProductBrand6.Enabled = False
        Me.txtProductBrand6.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProductBrand6.Location = New System.Drawing.Point(358, 164)
        Me.txtProductBrand6.Name = "txtProductBrand6"
        Me.txtProductBrand6.Size = New System.Drawing.Size(210, 32)
        Me.txtProductBrand6.TabIndex = 17
        '
        'txtCreateDate6
        '
        Me.txtCreateDate6.Enabled = False
        Me.txtCreateDate6.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCreateDate6.Location = New System.Drawing.Point(358, 202)
        Me.txtCreateDate6.Name = "txtCreateDate6"
        Me.txtCreateDate6.Size = New System.Drawing.Size(210, 32)
        Me.txtCreateDate6.TabIndex = 19
        '
        'txtProductName6
        '
        Me.txtProductName6.BackColor = System.Drawing.Color.White
        Me.txtProductName6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtProductName6.Enabled = False
        Me.txtProductName6.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProductName6.Location = New System.Drawing.Point(358, 50)
        Me.txtProductName6.Name = "txtProductName6"
        Me.txtProductName6.Size = New System.Drawing.Size(350, 25)
        Me.txtProductName6.TabIndex = 11
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(132, 201)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(220, 30)
        Me.Label5.TabIndex = 18
        Me.Label5.Text = "Create &Date : "
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(132, 49)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(220, 30)
        Me.Label8.TabIndex = 10
        Me.Label8.Text = "Product &Name : "
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtCategory6
        '
        Me.txtCategory6.Enabled = False
        Me.txtCategory6.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCategory6.Location = New System.Drawing.Point(358, 126)
        Me.txtCategory6.Name = "txtCategory6"
        Me.txtCategory6.Size = New System.Drawing.Size(210, 32)
        Me.txtCategory6.TabIndex = 15
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(132, 87)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(220, 30)
        Me.Label11.TabIndex = 12
        Me.Label11.Text = "&Unit Price : "
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label21
        '
        Me.Label21.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(132, 163)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(220, 30)
        Me.Label21.TabIndex = 16
        Me.Label21.Text = "Product &Brand : "
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtUnitPrice6
        '
        Me.txtUnitPrice6.Enabled = False
        Me.txtUnitPrice6.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUnitPrice6.Location = New System.Drawing.Point(358, 88)
        Me.txtUnitPrice6.Name = "txtUnitPrice6"
        Me.txtUnitPrice6.Size = New System.Drawing.Size(210, 32)
        Me.txtUnitPrice6.TabIndex = 13
        '
        'Label22
        '
        Me.Label22.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(132, 125)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(220, 30)
        Me.Label22.TabIndex = 14
        Me.Label22.Text = "Product &Category :"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtProductID6
        '
        Me.txtProductID6.Location = New System.Drawing.Point(437, 28)
        Me.txtProductID6.Name = "txtProductID6"
        Me.txtProductID6.Size = New System.Drawing.Size(210, 31)
        Me.txtProductID6.TabIndex = 1
        '
        'btnReset6
        '
        Me.btnReset6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset6.Location = New System.Drawing.Point(819, 26)
        Me.btnReset6.Name = "btnReset6"
        Me.btnReset6.Size = New System.Drawing.Size(160, 32)
        Me.btnReset6.TabIndex = 23
        Me.btnReset6.Text = "Reset"
        Me.btnReset6.UseVisualStyleBackColor = True
        '
        'Label23
        '
        Me.Label23.Location = New System.Drawing.Point(211, 28)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(220, 30)
        Me.Label23.TabIndex = 0
        Me.Label23.Text = "Product &ID : "
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnSearch6
        '
        Me.btnSearch6.Location = New System.Drawing.Point(653, 26)
        Me.btnSearch6.Name = "btnSearch6"
        Me.btnSearch6.Size = New System.Drawing.Size(160, 32)
        Me.btnSearch6.TabIndex = 2
        Me.btnSearch6.Text = "Search"
        Me.btnSearch6.UseVisualStyleBackColor = True
        '
        'ProductModule
        '
        Me.ProductModule.Controls.Add(Me.addProduct)
        Me.ProductModule.Controls.Add(Me.viewProduct)
        Me.ProductModule.Controls.Add(Me.editStock)
        Me.ProductModule.Controls.Add(Me.deleteStock)
        Me.ProductModule.Controls.Add(Me.TabPage3)
        Me.ProductModule.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ProductModule.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProductModule.Location = New System.Drawing.Point(0, 193)
        Me.ProductModule.Name = "ProductModule"
        Me.ProductModule.Padding = New System.Drawing.Point(18, 3)
        Me.ProductModule.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ProductModule.SelectedIndex = 0
        Me.ProductModule.Size = New System.Drawing.Size(1354, 540)
        Me.ProductModule.TabIndex = 3
        '
        'cmsClear
        '
        Me.cmsClear.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ClearToolStripMenuItem})
        Me.cmsClear.Name = "cmsClear"
        Me.cmsClear.Size = New System.Drawing.Size(102, 26)
        '
        'ClearToolStripMenuItem
        '
        Me.ClearToolStripMenuItem.Name = "ClearToolStripMenuItem"
        Me.ClearToolStripMenuItem.Size = New System.Drawing.Size(101, 22)
        Me.ClearToolStripMenuItem.Text = "&Clear"
        '
        'OmbakDataSet
        '
        Me.OmbakDataSet.DataSetName = "ombakDataSet"
        Me.OmbakDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ProductBindingSource
        '
        Me.ProductBindingSource.DataMember = "Product"
        Me.ProductBindingSource.DataSource = Me.OmbakDataSet
        '
        'ProductTableAdapter
        '
        Me.ProductTableAdapter.ClearBeforeFill = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.ombak.My.Resources.Resources.logo
        Me.PictureBox1.Location = New System.Drawing.Point(425, 10)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(500, 150)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 69
        Me.PictureBox1.TabStop = False
        '
        'backButton
        '
        Me.backButton.Image = CType(resources.GetObject("backButton.Image"), System.Drawing.Image)
        Me.backButton.Location = New System.Drawing.Point(12, 10)
        Me.backButton.Name = "backButton"
        Me.backButton.Size = New System.Drawing.Size(110, 65)
        Me.backButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.backButton.TabIndex = 73
        Me.backButton.TabStop = False
        '
        'lblStaffID
        '
        Me.lblStaffID.AutoSize = True
        Me.lblStaffID.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.lblStaffID.Location = New System.Drawing.Point(1120, 64)
        Me.lblStaffID.Name = "lblStaffID"
        Me.lblStaffID.Size = New System.Drawing.Size(0, 29)
        Me.lblStaffID.TabIndex = 90
        '
        'lblStaffName
        '
        Me.lblStaffName.AutoSize = True
        Me.lblStaffName.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.lblStaffName.Location = New System.Drawing.Point(1120, 112)
        Me.lblStaffName.Name = "lblStaffName"
        Me.lblStaffName.Size = New System.Drawing.Size(0, 29)
        Me.lblStaffName.TabIndex = 92
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label1.Location = New System.Drawing.Point(953, 112)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(149, 29)
        Me.Label1.TabIndex = 89
        Me.Label1.Text = "Staff Name : "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label2.Location = New System.Drawing.Point(995, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(107, 29)
        Me.Label2.TabIndex = 88
        Me.Label2.Text = "Staff ID : "
        '
        'ProductControl
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(1354, 733)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblStaffName)
        Me.Controls.Add(Me.lblStaffID)
        Me.Controls.Add(Me.backButton)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.ProductModule)
        Me.Name = "ProductControl"
        Me.Text = "ProductControl"
        Me.TabPage3.ResumeLayout(False)
        Me.TabControl3.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.DataGridView10, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.deleteStock.ResumeLayout(False)
        Me.deleteStock.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.byCategory.ResumeLayout(False)
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ByProductID.ResumeLayout(False)
        Me.ByProductID.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.byName.ResumeLayout(False)
        Me.byName.PerformLayout()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.bySupplierID.ResumeLayout(False)
        Me.bySupplierID.PerformLayout()
        CType(Me.DataGridView5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.viewProduct.ResumeLayout(False)
        Me.addProduct.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.editStock.ResumeLayout(False)
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ProductModule.ResumeLayout(False)
        Me.cmsClear.ResumeLayout(False)
        CType(Me.OmbakDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ProductBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.backButton, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents deleteStock As System.Windows.Forms.TabPage
    Friend WithEvents byCategory As System.Windows.Forms.TabPage
    Friend WithEvents btnSearch2 As System.Windows.Forms.Button
    Friend WithEvents ByProductID As System.Windows.Forms.TabPage
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Protected Friend WithEvents viewProduct As System.Windows.Forms.TabPage
    Friend WithEvents addProduct As System.Windows.Forms.TabPage
    Friend WithEvents editStock As System.Windows.Forms.TabPage
    Friend WithEvents ProductModule As System.Windows.Forms.TabControl
    Friend WithEvents txtProductID2 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents DataGridView4 As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents cboCategory1 As System.Windows.Forms.ComboBox
    Friend WithEvents btnReset0 As System.Windows.Forms.Button
    Friend WithEvents btnAdd0 As System.Windows.Forms.Button
    Friend WithEvents txtCreateDate1 As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtUnitPrice1 As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtProductName1 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtProductBrand2 As System.Windows.Forms.TextBox
    Friend WithEvents txtCategory2 As System.Windows.Forms.TextBox
    Friend WithEvents txtCreateDate2 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtUnitPrice2 As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txtProductName2 As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents txtQuantity2 As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents TabControl2 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtQuantity6 As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents txtProductBrand6 As System.Windows.Forms.TextBox
    Friend WithEvents txtCreateDate6 As System.Windows.Forms.TextBox
    Friend WithEvents txtProductName6 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtCategory6 As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txtUnitPrice6 As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtProductID6 As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents btnSearch6 As System.Windows.Forms.Button
    Friend WithEvents txtProductID1 As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents btnUpdate6 As System.Windows.Forms.Button
    Friend WithEvents cmsClear As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ClearToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents txtProductBrand1 As System.Windows.Forms.TextBox
    Friend WithEvents btnReset6 As System.Windows.Forms.Button
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents btnReset9 As System.Windows.Forms.Button
    Friend WithEvents btnDelete9 As System.Windows.Forms.Button
    Friend WithEvents txtQuantity9 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtProductBrand9 As System.Windows.Forms.TextBox
    Friend WithEvents txtCreateDate9 As System.Windows.Forms.TextBox
    Friend WithEvents txtProductName9 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents txtCategory9 As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents txtUnitPrice9 As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents txtProductID9 As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents btnSearch9 As System.Windows.Forms.Button
    Friend WithEvents byName As System.Windows.Forms.TabPage
    Friend WithEvents DataGridView3 As System.Windows.Forms.DataGridView
    Friend WithEvents txtProductName3 As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents cboProductCategory4 As System.Windows.Forms.ComboBox
    Friend WithEvents txtSupplierID2 As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtSupplierID6 As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents txtSupplierID9 As System.Windows.Forms.TextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents bySupplierID As System.Windows.Forms.TabPage
    Friend WithEvents DataGridView5 As System.Windows.Forms.DataGridView
    Friend WithEvents btnSearch5 As System.Windows.Forms.Button
    Friend WithEvents txtSupplierID5 As System.Windows.Forms.TextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents cboSupplierID1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents OmbakDataSet As ombak.ombakDataSet
    Friend WithEvents ProductBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents ProductTableAdapter As ombak.ombakDataSetTableAdapters.ProductTableAdapter
    Friend WithEvents TabControl3 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents DataGridView10 As System.Windows.Forms.DataGridView
    Friend WithEvents txtQuantity10 As System.Windows.Forms.TextBox
    Friend WithEvents btnReset10 As System.Windows.Forms.Button
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents btnSearch10 As System.Windows.Forms.Button
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents txtSupplierID11 As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents btnAdd11 As System.Windows.Forms.Button
    Friend WithEvents txtQuantity11 As System.Windows.Forms.TextBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents txtProductBrand11 As System.Windows.Forms.TextBox
    Friend WithEvents txtProductName11 As System.Windows.Forms.TextBox
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents txtCategory11 As System.Windows.Forms.TextBox
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents txtUnitPrice11 As System.Windows.Forms.TextBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents txtProductID11 As System.Windows.Forms.TextBox
    Friend WithEvents btnReset11 As System.Windows.Forms.Button
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents btnSearch11 As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents backButton As System.Windows.Forms.PictureBox
    Friend WithEvents lblStaffID As System.Windows.Forms.Label
    Friend WithEvents lblStaffName As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtAddAmount As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
End Class
