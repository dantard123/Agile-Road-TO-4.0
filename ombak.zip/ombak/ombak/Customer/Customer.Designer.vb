﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Customer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Customer))
        Me.TabControl = New System.Windows.Forms.TabControl()
        Me.TapPage1 = New System.Windows.Forms.TabPage()
        Me.gbAddCustomer = New System.Windows.Forms.GroupBox()
        Me.btnAAdd = New System.Windows.Forms.PictureBox()
        Me.btnACancel = New System.Windows.Forms.PictureBox()
        Me.txtAHomeAddress = New System.Windows.Forms.TextBox()
        Me.txtAContact = New System.Windows.Forms.TextBox()
        Me.contact = New System.Windows.Forms.Label()
        Me.cboxAEmail2 = New System.Windows.Forms.ComboBox()
        Me.txtAEmail1 = New System.Windows.Forms.TextBox()
        Me.rbAFemale = New System.Windows.Forms.RadioButton()
        Me.rbAMale = New System.Windows.Forms.RadioButton()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtACustomerIC = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtACusName = New System.Windows.Forms.TextBox()
        Me.txtACusID = New System.Windows.Forms.TextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.gbViewCustomer = New System.Windows.Forms.GroupBox()
        Me.btnVCancel = New System.Windows.Forms.PictureBox()
        Me.txtVGender = New System.Windows.Forms.TextBox()
        Me.cboxVCusID = New System.Windows.Forms.ComboBox()
        Me.txtVPoint = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtVHomeAddress = New System.Windows.Forms.TextBox()
        Me.txtVContact = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtVEmail = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtVCustomerIC = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtVCusName = New System.Windows.Forms.TextBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.gbEditCustomer = New System.Windows.Forms.GroupBox()
        Me.btnECancel = New System.Windows.Forms.PictureBox()
        Me.btnEUpdate = New System.Windows.Forms.PictureBox()
        Me.txtEGender = New System.Windows.Forms.TextBox()
        Me.cboxECusID = New System.Windows.Forms.ComboBox()
        Me.txtEPoint = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtEHomeAddress = New System.Windows.Forms.TextBox()
        Me.txtEContact = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtEEmail = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtECustomerIC = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtECusName = New System.Windows.Forms.TextBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.gbDeleteCustomer = New System.Windows.Forms.GroupBox()
        Me.btnDCancel = New System.Windows.Forms.PictureBox()
        Me.btnDDelete = New System.Windows.Forms.PictureBox()
        Me.txtDGender = New System.Windows.Forms.TextBox()
        Me.cboxDCusID = New System.Windows.Forms.ComboBox()
        Me.txtDPoint = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtDHomeAddress = New System.Windows.Forms.TextBox()
        Me.txtDContact = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtDEmail = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtDCustomerIC = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.txtDCusName = New System.Windows.Forms.TextBox()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.gbPrizeRedemption = New System.Windows.Forms.GroupBox()
        Me.btnPCancel = New System.Windows.Forms.PictureBox()
        Me.btnPRedeem = New System.Windows.Forms.PictureBox()
        Me.cboxPPrizeAmount = New System.Windows.Forms.ComboBox()
        Me.txtPBalancePoint = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.cboxPSelectPrize = New System.Windows.Forms.ComboBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.txtPSinglePrizePoint = New System.Windows.Forms.TextBox()
        Me.cboxPCusID = New System.Windows.Forms.ComboBox()
        Me.txtPTotalPrizePoint = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.singlepoint = New System.Windows.Forms.Label()
        Me.txtPPoint = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.prizeamount = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.txtPCusName = New System.Windows.Forms.TextBox()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.gbViewRedemption = New System.Windows.Forms.GroupBox()
        Me.btnRCancel = New System.Windows.Forms.PictureBox()
        Me.txtRPrizeAmount = New System.Windows.Forms.TextBox()
        Me.txtRPrizeName = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.txtRPrizePoint = New System.Windows.Forms.TextBox()
        Me.cboxRRedemptionID = New System.Windows.Forms.ComboBox()
        Me.txtRTotalPrizePoint = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.txtRCustomerName = New System.Windows.Forms.TextBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.txtRCustomerID = New System.Windows.Forms.TextBox()
        Me.lblStaffName = New System.Windows.Forms.Label()
        Me.lblStaffID = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.backButton = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.TabControl.SuspendLayout()
        Me.TapPage1.SuspendLayout()
        Me.gbAddCustomer.SuspendLayout()
        CType(Me.btnAAdd, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnACancel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.gbViewCustomer.SuspendLayout()
        CType(Me.btnVCancel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.gbEditCustomer.SuspendLayout()
        CType(Me.btnECancel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnEUpdate, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        Me.gbDeleteCustomer.SuspendLayout()
        CType(Me.btnDCancel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnDDelete, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        Me.gbPrizeRedemption.SuspendLayout()
        CType(Me.btnPCancel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnPRedeem, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage1.SuspendLayout()
        Me.gbViewRedemption.SuspendLayout()
        CType(Me.btnRCancel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.backButton, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl
        '
        Me.TabControl.Controls.Add(Me.TapPage1)
        Me.TabControl.Controls.Add(Me.TabPage2)
        Me.TabControl.Controls.Add(Me.TabPage3)
        Me.TabControl.Controls.Add(Me.TabPage4)
        Me.TabControl.Controls.Add(Me.TabPage5)
        Me.TabControl.Controls.Add(Me.TabPage1)
        Me.TabControl.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TabControl.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl.Location = New System.Drawing.Point(0, 160)
        Me.TabControl.Name = "TabControl"
        Me.TabControl.Padding = New System.Drawing.Point(18, 3)
        Me.TabControl.SelectedIndex = 0
        Me.TabControl.Size = New System.Drawing.Size(1350, 573)
        Me.TabControl.TabIndex = 69
        '
        'TapPage1
        '
        Me.TapPage1.Controls.Add(Me.gbAddCustomer)
        Me.TapPage1.Location = New System.Drawing.Point(4, 34)
        Me.TapPage1.Name = "TapPage1"
        Me.TapPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TapPage1.Size = New System.Drawing.Size(1342, 535)
        Me.TapPage1.TabIndex = 0
        Me.TapPage1.Text = "Add Customer"
        Me.TapPage1.UseVisualStyleBackColor = True
        '
        'gbAddCustomer
        '
        Me.gbAddCustomer.Controls.Add(Me.btnAAdd)
        Me.gbAddCustomer.Controls.Add(Me.btnACancel)
        Me.gbAddCustomer.Controls.Add(Me.txtAHomeAddress)
        Me.gbAddCustomer.Controls.Add(Me.txtAContact)
        Me.gbAddCustomer.Controls.Add(Me.contact)
        Me.gbAddCustomer.Controls.Add(Me.cboxAEmail2)
        Me.gbAddCustomer.Controls.Add(Me.txtAEmail1)
        Me.gbAddCustomer.Controls.Add(Me.rbAFemale)
        Me.gbAddCustomer.Controls.Add(Me.rbAMale)
        Me.gbAddCustomer.Controls.Add(Me.Label6)
        Me.gbAddCustomer.Controls.Add(Me.Label7)
        Me.gbAddCustomer.Controls.Add(Me.txtACustomerIC)
        Me.gbAddCustomer.Controls.Add(Me.Label1)
        Me.gbAddCustomer.Controls.Add(Me.Label5)
        Me.gbAddCustomer.Controls.Add(Me.Label3)
        Me.gbAddCustomer.Controls.Add(Me.Label2)
        Me.gbAddCustomer.Controls.Add(Me.txtACusName)
        Me.gbAddCustomer.Controls.Add(Me.txtACusID)
        Me.gbAddCustomer.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.gbAddCustomer.Location = New System.Drawing.Point(220, 20)
        Me.gbAddCustomer.Name = "gbAddCustomer"
        Me.gbAddCustomer.Size = New System.Drawing.Size(900, 505)
        Me.gbAddCustomer.TabIndex = 2
        Me.gbAddCustomer.TabStop = False
        Me.gbAddCustomer.Text = "Add New Customer"
        '
        'btnAAdd
        '
        Me.btnAAdd.Image = Global.ombak.My.Resources.Resources.insertbutton
        Me.btnAAdd.Location = New System.Drawing.Point(520, 455)
        Me.btnAAdd.Name = "btnAAdd"
        Me.btnAAdd.Size = New System.Drawing.Size(100, 50)
        Me.btnAAdd.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.btnAAdd.TabIndex = 150
        Me.btnAAdd.TabStop = False
        '
        'btnACancel
        '
        Me.btnACancel.Image = Global.ombak.My.Resources.Resources.cancelbutton
        Me.btnACancel.Location = New System.Drawing.Point(626, 455)
        Me.btnACancel.Name = "btnACancel"
        Me.btnACancel.Size = New System.Drawing.Size(100, 50)
        Me.btnACancel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.btnACancel.TabIndex = 149
        Me.btnACancel.TabStop = False
        '
        'txtAHomeAddress
        '
        Me.txtAHomeAddress.Location = New System.Drawing.Point(367, 313)
        Me.txtAHomeAddress.Multiline = True
        Me.txtAHomeAddress.Name = "txtAHomeAddress"
        Me.txtAHomeAddress.Size = New System.Drawing.Size(359, 90)
        Me.txtAHomeAddress.TabIndex = 9
        '
        'txtAContact
        '
        Me.txtAContact.Location = New System.Drawing.Point(367, 167)
        Me.txtAContact.Name = "txtAContact"
        Me.txtAContact.Size = New System.Drawing.Size(359, 32)
        Me.txtAContact.TabIndex = 4
        '
        'contact
        '
        Me.contact.AutoSize = True
        Me.contact.Location = New System.Drawing.Point(247, 170)
        Me.contact.Name = "contact"
        Me.contact.Size = New System.Drawing.Size(105, 26)
        Me.contact.TabIndex = 148
        Me.contact.Text = "Contact : "
        '
        'cboxAEmail2
        '
        Me.cboxAEmail2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboxAEmail2.FormattingEnabled = True
        Me.cboxAEmail2.Items.AddRange(New Object() {"@hotmail.com", "@yahoo.com", "@gmail.com", "@outlook.com", "@live.com"})
        Me.cboxAEmail2.Location = New System.Drawing.Point(543, 261)
        Me.cboxAEmail2.Name = "cboxAEmail2"
        Me.cboxAEmail2.Size = New System.Drawing.Size(183, 33)
        Me.cboxAEmail2.TabIndex = 8
        '
        'txtAEmail1
        '
        Me.txtAEmail1.Location = New System.Drawing.Point(367, 262)
        Me.txtAEmail1.Name = "txtAEmail1"
        Me.txtAEmail1.Size = New System.Drawing.Size(170, 32)
        Me.txtAEmail1.TabIndex = 7
        '
        'rbAFemale
        '
        Me.rbAFemale.AutoSize = True
        Me.rbAFemale.Location = New System.Drawing.Point(463, 215)
        Me.rbAFemale.Name = "rbAFemale"
        Me.rbAFemale.Size = New System.Drawing.Size(103, 30)
        Me.rbAFemale.TabIndex = 6
        Me.rbAFemale.TabStop = True
        Me.rbAFemale.Text = "Female"
        Me.rbAFemale.UseVisualStyleBackColor = True
        '
        'rbAMale
        '
        Me.rbAMale.AutoSize = True
        Me.rbAMale.Location = New System.Drawing.Point(367, 215)
        Me.rbAMale.Name = "rbAMale"
        Me.rbAMale.Size = New System.Drawing.Size(77, 30)
        Me.rbAMale.TabIndex = 5
        Me.rbAMale.TabStop = True
        Me.rbAMale.Text = "Male"
        Me.rbAMale.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(250, 218)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(102, 26)
        Me.Label6.TabIndex = 142
        Me.Label6.Text = "Gender : "
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(199, 128)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(153, 26)
        Me.Label7.TabIndex = 141
        Me.Label7.Text = "Customer IC : "
        '
        'txtACustomerIC
        '
        Me.txtACustomerIC.Location = New System.Drawing.Point(367, 122)
        Me.txtACustomerIC.Name = "txtACustomerIC"
        Me.txtACustomerIC.Size = New System.Drawing.Size(359, 32)
        Me.txtACustomerIC.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(177, 316)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(175, 26)
        Me.Label1.TabIndex = 139
        Me.Label1.Text = "Home Address : "
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(180, 264)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(172, 26)
        Me.Label5.TabIndex = 138
        Me.Label5.Text = "Email Address : "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(162, 79)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(190, 26)
        Me.Label3.TabIndex = 135
        Me.Label3.Text = "Customer Name : "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(199, 34)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(153, 26)
        Me.Label2.TabIndex = 134
        Me.Label2.Text = "Customer ID : "
        '
        'txtACusName
        '
        Me.txtACusName.Location = New System.Drawing.Point(367, 76)
        Me.txtACusName.Name = "txtACusName"
        Me.txtACusName.Size = New System.Drawing.Size(359, 32)
        Me.txtACusName.TabIndex = 2
        '
        'txtACusID
        '
        Me.txtACusID.Enabled = False
        Me.txtACusID.Location = New System.Drawing.Point(367, 31)
        Me.txtACusID.Name = "txtACusID"
        Me.txtACusID.Size = New System.Drawing.Size(359, 32)
        Me.txtACusID.TabIndex = 1
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.gbViewCustomer)
        Me.TabPage2.Location = New System.Drawing.Point(4, 34)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1342, 535)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "View Customer"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'gbViewCustomer
        '
        Me.gbViewCustomer.Controls.Add(Me.btnVCancel)
        Me.gbViewCustomer.Controls.Add(Me.txtVGender)
        Me.gbViewCustomer.Controls.Add(Me.cboxVCusID)
        Me.gbViewCustomer.Controls.Add(Me.txtVPoint)
        Me.gbViewCustomer.Controls.Add(Me.Label15)
        Me.gbViewCustomer.Controls.Add(Me.txtVHomeAddress)
        Me.gbViewCustomer.Controls.Add(Me.txtVContact)
        Me.gbViewCustomer.Controls.Add(Me.Label8)
        Me.gbViewCustomer.Controls.Add(Me.txtVEmail)
        Me.gbViewCustomer.Controls.Add(Me.Label9)
        Me.gbViewCustomer.Controls.Add(Me.Label10)
        Me.gbViewCustomer.Controls.Add(Me.txtVCustomerIC)
        Me.gbViewCustomer.Controls.Add(Me.Label11)
        Me.gbViewCustomer.Controls.Add(Me.Label12)
        Me.gbViewCustomer.Controls.Add(Me.Label13)
        Me.gbViewCustomer.Controls.Add(Me.Label14)
        Me.gbViewCustomer.Controls.Add(Me.txtVCusName)
        Me.gbViewCustomer.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.gbViewCustomer.Location = New System.Drawing.Point(220, 20)
        Me.gbViewCustomer.Name = "gbViewCustomer"
        Me.gbViewCustomer.Size = New System.Drawing.Size(900, 505)
        Me.gbViewCustomer.TabIndex = 2
        Me.gbViewCustomer.TabStop = False
        Me.gbViewCustomer.Text = "View Customer Detail"
        '
        'btnVCancel
        '
        Me.btnVCancel.Image = Global.ombak.My.Resources.Resources.cancelbutton
        Me.btnVCancel.Location = New System.Drawing.Point(626, 455)
        Me.btnVCancel.Name = "btnVCancel"
        Me.btnVCancel.Size = New System.Drawing.Size(100, 50)
        Me.btnVCancel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.btnVCancel.TabIndex = 152
        Me.btnVCancel.TabStop = False
        '
        'txtVGender
        '
        Me.txtVGender.Enabled = False
        Me.txtVGender.Location = New System.Drawing.Point(367, 215)
        Me.txtVGender.Name = "txtVGender"
        Me.txtVGender.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtVGender.Size = New System.Drawing.Size(359, 32)
        Me.txtVGender.TabIndex = 5
        '
        'cboxVCusID
        '
        Me.cboxVCusID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboxVCusID.FormattingEnabled = True
        Me.cboxVCusID.Location = New System.Drawing.Point(367, 31)
        Me.cboxVCusID.Name = "cboxVCusID"
        Me.cboxVCusID.Size = New System.Drawing.Size(359, 33)
        Me.cboxVCusID.TabIndex = 1
        '
        'txtVPoint
        '
        Me.txtVPoint.Enabled = False
        Me.txtVPoint.Location = New System.Drawing.Point(367, 418)
        Me.txtVPoint.Name = "txtVPoint"
        Me.txtVPoint.Size = New System.Drawing.Size(359, 32)
        Me.txtVPoint.TabIndex = 8
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(190, 418)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(162, 26)
        Me.Label15.TabIndex = 151
        Me.Label15.Text = "Point Amount : "
        '
        'txtVHomeAddress
        '
        Me.txtVHomeAddress.Enabled = False
        Me.txtVHomeAddress.Location = New System.Drawing.Point(367, 313)
        Me.txtVHomeAddress.Multiline = True
        Me.txtVHomeAddress.Name = "txtVHomeAddress"
        Me.txtVHomeAddress.Size = New System.Drawing.Size(359, 90)
        Me.txtVHomeAddress.TabIndex = 7
        '
        'txtVContact
        '
        Me.txtVContact.Enabled = False
        Me.txtVContact.Location = New System.Drawing.Point(367, 167)
        Me.txtVContact.Name = "txtVContact"
        Me.txtVContact.Size = New System.Drawing.Size(359, 32)
        Me.txtVContact.TabIndex = 4
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(247, 170)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(105, 26)
        Me.Label8.TabIndex = 148
        Me.Label8.Text = "Contact : "
        '
        'txtVEmail
        '
        Me.txtVEmail.Enabled = False
        Me.txtVEmail.Location = New System.Drawing.Point(367, 262)
        Me.txtVEmail.Name = "txtVEmail"
        Me.txtVEmail.Size = New System.Drawing.Size(359, 32)
        Me.txtVEmail.TabIndex = 6
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(250, 218)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(102, 26)
        Me.Label9.TabIndex = 142
        Me.Label9.Text = "Gender : "
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(196, 125)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(153, 26)
        Me.Label10.TabIndex = 141
        Me.Label10.Text = "Customer IC : "
        '
        'txtVCustomerIC
        '
        Me.txtVCustomerIC.Enabled = False
        Me.txtVCustomerIC.Location = New System.Drawing.Point(367, 122)
        Me.txtVCustomerIC.Name = "txtVCustomerIC"
        Me.txtVCustomerIC.Size = New System.Drawing.Size(359, 32)
        Me.txtVCustomerIC.TabIndex = 3
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(177, 316)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(175, 26)
        Me.Label11.TabIndex = 139
        Me.Label11.Text = "Home Address : "
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(180, 264)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(172, 26)
        Me.Label12.TabIndex = 138
        Me.Label12.Text = "Email Address : "
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(162, 79)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(190, 26)
        Me.Label13.TabIndex = 135
        Me.Label13.Text = "Customer Name : "
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(199, 34)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(153, 26)
        Me.Label14.TabIndex = 134
        Me.Label14.Text = "Customer ID : "
        '
        'txtVCusName
        '
        Me.txtVCusName.Enabled = False
        Me.txtVCusName.Location = New System.Drawing.Point(367, 76)
        Me.txtVCusName.Name = "txtVCusName"
        Me.txtVCusName.Size = New System.Drawing.Size(359, 32)
        Me.txtVCusName.TabIndex = 2
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.gbEditCustomer)
        Me.TabPage3.Location = New System.Drawing.Point(4, 34)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1342, 535)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Edit Customer"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'gbEditCustomer
        '
        Me.gbEditCustomer.Controls.Add(Me.btnECancel)
        Me.gbEditCustomer.Controls.Add(Me.btnEUpdate)
        Me.gbEditCustomer.Controls.Add(Me.txtEGender)
        Me.gbEditCustomer.Controls.Add(Me.cboxECusID)
        Me.gbEditCustomer.Controls.Add(Me.txtEPoint)
        Me.gbEditCustomer.Controls.Add(Me.Label4)
        Me.gbEditCustomer.Controls.Add(Me.txtEHomeAddress)
        Me.gbEditCustomer.Controls.Add(Me.txtEContact)
        Me.gbEditCustomer.Controls.Add(Me.Label16)
        Me.gbEditCustomer.Controls.Add(Me.txtEEmail)
        Me.gbEditCustomer.Controls.Add(Me.Label17)
        Me.gbEditCustomer.Controls.Add(Me.Label18)
        Me.gbEditCustomer.Controls.Add(Me.txtECustomerIC)
        Me.gbEditCustomer.Controls.Add(Me.Label19)
        Me.gbEditCustomer.Controls.Add(Me.Label20)
        Me.gbEditCustomer.Controls.Add(Me.Label21)
        Me.gbEditCustomer.Controls.Add(Me.Label22)
        Me.gbEditCustomer.Controls.Add(Me.txtECusName)
        Me.gbEditCustomer.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.gbEditCustomer.Location = New System.Drawing.Point(220, 20)
        Me.gbEditCustomer.Name = "gbEditCustomer"
        Me.gbEditCustomer.Size = New System.Drawing.Size(900, 505)
        Me.gbEditCustomer.TabIndex = 3
        Me.gbEditCustomer.TabStop = False
        Me.gbEditCustomer.Text = "Edit Customer Detail"
        '
        'btnECancel
        '
        Me.btnECancel.Image = Global.ombak.My.Resources.Resources.cancelbutton
        Me.btnECancel.Location = New System.Drawing.Point(626, 459)
        Me.btnECancel.Name = "btnECancel"
        Me.btnECancel.Size = New System.Drawing.Size(100, 50)
        Me.btnECancel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.btnECancel.TabIndex = 153
        Me.btnECancel.TabStop = False
        '
        'btnEUpdate
        '
        Me.btnEUpdate.Image = Global.ombak.My.Resources.Resources.updatebutton
        Me.btnEUpdate.Location = New System.Drawing.Point(520, 459)
        Me.btnEUpdate.Name = "btnEUpdate"
        Me.btnEUpdate.Size = New System.Drawing.Size(100, 50)
        Me.btnEUpdate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.btnEUpdate.TabIndex = 152
        Me.btnEUpdate.TabStop = False
        '
        'txtEGender
        '
        Me.txtEGender.Enabled = False
        Me.txtEGender.Location = New System.Drawing.Point(367, 215)
        Me.txtEGender.Name = "txtEGender"
        Me.txtEGender.Size = New System.Drawing.Size(359, 32)
        Me.txtEGender.TabIndex = 5
        '
        'cboxECusID
        '
        Me.cboxECusID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboxECusID.FormattingEnabled = True
        Me.cboxECusID.Location = New System.Drawing.Point(367, 31)
        Me.cboxECusID.Name = "cboxECusID"
        Me.cboxECusID.Size = New System.Drawing.Size(359, 33)
        Me.cboxECusID.TabIndex = 1
        '
        'txtEPoint
        '
        Me.txtEPoint.Enabled = False
        Me.txtEPoint.Location = New System.Drawing.Point(367, 418)
        Me.txtEPoint.Name = "txtEPoint"
        Me.txtEPoint.Size = New System.Drawing.Size(359, 32)
        Me.txtEPoint.TabIndex = 8
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(190, 418)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(162, 26)
        Me.Label4.TabIndex = 151
        Me.Label4.Text = "Point Amount : "
        '
        'txtEHomeAddress
        '
        Me.txtEHomeAddress.Location = New System.Drawing.Point(367, 313)
        Me.txtEHomeAddress.Multiline = True
        Me.txtEHomeAddress.Name = "txtEHomeAddress"
        Me.txtEHomeAddress.Size = New System.Drawing.Size(359, 90)
        Me.txtEHomeAddress.TabIndex = 7
        '
        'txtEContact
        '
        Me.txtEContact.Location = New System.Drawing.Point(367, 167)
        Me.txtEContact.Name = "txtEContact"
        Me.txtEContact.Size = New System.Drawing.Size(359, 32)
        Me.txtEContact.TabIndex = 4
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(247, 170)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(105, 26)
        Me.Label16.TabIndex = 148
        Me.Label16.Text = "Contact : "
        '
        'txtEEmail
        '
        Me.txtEEmail.Location = New System.Drawing.Point(367, 262)
        Me.txtEEmail.Name = "txtEEmail"
        Me.txtEEmail.Size = New System.Drawing.Size(359, 32)
        Me.txtEEmail.TabIndex = 6
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(250, 218)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(102, 26)
        Me.Label17.TabIndex = 142
        Me.Label17.Text = "Gender : "
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(199, 125)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(153, 26)
        Me.Label18.TabIndex = 141
        Me.Label18.Text = "Customer IC : "
        '
        'txtECustomerIC
        '
        Me.txtECustomerIC.Enabled = False
        Me.txtECustomerIC.Location = New System.Drawing.Point(367, 122)
        Me.txtECustomerIC.Name = "txtECustomerIC"
        Me.txtECustomerIC.Size = New System.Drawing.Size(359, 32)
        Me.txtECustomerIC.TabIndex = 3
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(177, 316)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(175, 26)
        Me.Label19.TabIndex = 139
        Me.Label19.Text = "Home Address : "
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(180, 264)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(172, 26)
        Me.Label20.TabIndex = 138
        Me.Label20.Text = "Email Address : "
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(162, 79)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(190, 26)
        Me.Label21.TabIndex = 135
        Me.Label21.Text = "Customer Name : "
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(199, 34)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(153, 26)
        Me.Label22.TabIndex = 134
        Me.Label22.Text = "Customer ID : "
        '
        'txtECusName
        '
        Me.txtECusName.Enabled = False
        Me.txtECusName.Location = New System.Drawing.Point(367, 76)
        Me.txtECusName.Name = "txtECusName"
        Me.txtECusName.Size = New System.Drawing.Size(359, 32)
        Me.txtECusName.TabIndex = 2
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.gbDeleteCustomer)
        Me.TabPage4.Location = New System.Drawing.Point(4, 34)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(1342, 535)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Delete Customer"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'gbDeleteCustomer
        '
        Me.gbDeleteCustomer.Controls.Add(Me.btnDCancel)
        Me.gbDeleteCustomer.Controls.Add(Me.btnDDelete)
        Me.gbDeleteCustomer.Controls.Add(Me.txtDGender)
        Me.gbDeleteCustomer.Controls.Add(Me.cboxDCusID)
        Me.gbDeleteCustomer.Controls.Add(Me.txtDPoint)
        Me.gbDeleteCustomer.Controls.Add(Me.Label23)
        Me.gbDeleteCustomer.Controls.Add(Me.txtDHomeAddress)
        Me.gbDeleteCustomer.Controls.Add(Me.txtDContact)
        Me.gbDeleteCustomer.Controls.Add(Me.Label24)
        Me.gbDeleteCustomer.Controls.Add(Me.txtDEmail)
        Me.gbDeleteCustomer.Controls.Add(Me.Label25)
        Me.gbDeleteCustomer.Controls.Add(Me.Label26)
        Me.gbDeleteCustomer.Controls.Add(Me.txtDCustomerIC)
        Me.gbDeleteCustomer.Controls.Add(Me.Label27)
        Me.gbDeleteCustomer.Controls.Add(Me.Label28)
        Me.gbDeleteCustomer.Controls.Add(Me.Label29)
        Me.gbDeleteCustomer.Controls.Add(Me.Label30)
        Me.gbDeleteCustomer.Controls.Add(Me.txtDCusName)
        Me.gbDeleteCustomer.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.gbDeleteCustomer.Location = New System.Drawing.Point(220, 20)
        Me.gbDeleteCustomer.Name = "gbDeleteCustomer"
        Me.gbDeleteCustomer.Size = New System.Drawing.Size(900, 505)
        Me.gbDeleteCustomer.TabIndex = 4
        Me.gbDeleteCustomer.TabStop = False
        Me.gbDeleteCustomer.Text = "Delete Customer"
        '
        'btnDCancel
        '
        Me.btnDCancel.Image = Global.ombak.My.Resources.Resources.cancelbutton
        Me.btnDCancel.Location = New System.Drawing.Point(626, 456)
        Me.btnDCancel.Name = "btnDCancel"
        Me.btnDCancel.Size = New System.Drawing.Size(100, 50)
        Me.btnDCancel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.btnDCancel.TabIndex = 153
        Me.btnDCancel.TabStop = False
        '
        'btnDDelete
        '
        Me.btnDDelete.Image = Global.ombak.My.Resources.Resources.deletebutton
        Me.btnDDelete.Location = New System.Drawing.Point(520, 455)
        Me.btnDDelete.Name = "btnDDelete"
        Me.btnDDelete.Size = New System.Drawing.Size(100, 50)
        Me.btnDDelete.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.btnDDelete.TabIndex = 152
        Me.btnDDelete.TabStop = False
        '
        'txtDGender
        '
        Me.txtDGender.Enabled = False
        Me.txtDGender.Location = New System.Drawing.Point(367, 215)
        Me.txtDGender.Name = "txtDGender"
        Me.txtDGender.Size = New System.Drawing.Size(359, 32)
        Me.txtDGender.TabIndex = 5
        '
        'cboxDCusID
        '
        Me.cboxDCusID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboxDCusID.FormattingEnabled = True
        Me.cboxDCusID.Location = New System.Drawing.Point(367, 31)
        Me.cboxDCusID.Name = "cboxDCusID"
        Me.cboxDCusID.Size = New System.Drawing.Size(359, 33)
        Me.cboxDCusID.TabIndex = 1
        '
        'txtDPoint
        '
        Me.txtDPoint.Enabled = False
        Me.txtDPoint.Location = New System.Drawing.Point(367, 418)
        Me.txtDPoint.Name = "txtDPoint"
        Me.txtDPoint.Size = New System.Drawing.Size(359, 32)
        Me.txtDPoint.TabIndex = 8
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(190, 418)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(162, 26)
        Me.Label23.TabIndex = 151
        Me.Label23.Text = "Point Amount : "
        '
        'txtDHomeAddress
        '
        Me.txtDHomeAddress.Enabled = False
        Me.txtDHomeAddress.Location = New System.Drawing.Point(367, 313)
        Me.txtDHomeAddress.Multiline = True
        Me.txtDHomeAddress.Name = "txtDHomeAddress"
        Me.txtDHomeAddress.Size = New System.Drawing.Size(359, 90)
        Me.txtDHomeAddress.TabIndex = 7
        '
        'txtDContact
        '
        Me.txtDContact.Enabled = False
        Me.txtDContact.Location = New System.Drawing.Point(367, 167)
        Me.txtDContact.Name = "txtDContact"
        Me.txtDContact.Size = New System.Drawing.Size(359, 32)
        Me.txtDContact.TabIndex = 4
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(247, 170)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(105, 26)
        Me.Label24.TabIndex = 148
        Me.Label24.Text = "Contact : "
        '
        'txtDEmail
        '
        Me.txtDEmail.Enabled = False
        Me.txtDEmail.Location = New System.Drawing.Point(367, 262)
        Me.txtDEmail.Name = "txtDEmail"
        Me.txtDEmail.Size = New System.Drawing.Size(359, 32)
        Me.txtDEmail.TabIndex = 6
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(250, 218)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(102, 26)
        Me.Label25.TabIndex = 142
        Me.Label25.Text = "Gender : "
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(199, 125)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(153, 26)
        Me.Label26.TabIndex = 141
        Me.Label26.Text = "Customer IC : "
        '
        'txtDCustomerIC
        '
        Me.txtDCustomerIC.Enabled = False
        Me.txtDCustomerIC.Location = New System.Drawing.Point(367, 122)
        Me.txtDCustomerIC.Name = "txtDCustomerIC"
        Me.txtDCustomerIC.Size = New System.Drawing.Size(359, 32)
        Me.txtDCustomerIC.TabIndex = 3
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(177, 316)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(175, 26)
        Me.Label27.TabIndex = 139
        Me.Label27.Text = "Home Address : "
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(180, 264)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(172, 26)
        Me.Label28.TabIndex = 138
        Me.Label28.Text = "Email Address : "
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(162, 79)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(190, 26)
        Me.Label29.TabIndex = 135
        Me.Label29.Text = "Customer Name : "
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(199, 34)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(153, 26)
        Me.Label30.TabIndex = 134
        Me.Label30.Text = "Customer ID : "
        '
        'txtDCusName
        '
        Me.txtDCusName.Enabled = False
        Me.txtDCusName.Location = New System.Drawing.Point(367, 76)
        Me.txtDCusName.Name = "txtDCusName"
        Me.txtDCusName.Size = New System.Drawing.Size(359, 32)
        Me.txtDCusName.TabIndex = 2
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.gbPrizeRedemption)
        Me.TabPage5.Location = New System.Drawing.Point(4, 34)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(1342, 535)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Prize Redemption"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'gbPrizeRedemption
        '
        Me.gbPrizeRedemption.Controls.Add(Me.btnPCancel)
        Me.gbPrizeRedemption.Controls.Add(Me.btnPRedeem)
        Me.gbPrizeRedemption.Controls.Add(Me.cboxPPrizeAmount)
        Me.gbPrizeRedemption.Controls.Add(Me.txtPBalancePoint)
        Me.gbPrizeRedemption.Controls.Add(Me.Label31)
        Me.gbPrizeRedemption.Controls.Add(Me.cboxPSelectPrize)
        Me.gbPrizeRedemption.Controls.Add(Me.Label34)
        Me.gbPrizeRedemption.Controls.Add(Me.txtPSinglePrizePoint)
        Me.gbPrizeRedemption.Controls.Add(Me.cboxPCusID)
        Me.gbPrizeRedemption.Controls.Add(Me.txtPTotalPrizePoint)
        Me.gbPrizeRedemption.Controls.Add(Me.Label32)
        Me.gbPrizeRedemption.Controls.Add(Me.singlepoint)
        Me.gbPrizeRedemption.Controls.Add(Me.txtPPoint)
        Me.gbPrizeRedemption.Controls.Add(Me.Label35)
        Me.gbPrizeRedemption.Controls.Add(Me.prizeamount)
        Me.gbPrizeRedemption.Controls.Add(Me.Label37)
        Me.gbPrizeRedemption.Controls.Add(Me.Label38)
        Me.gbPrizeRedemption.Controls.Add(Me.txtPCusName)
        Me.gbPrizeRedemption.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.gbPrizeRedemption.Location = New System.Drawing.Point(220, 20)
        Me.gbPrizeRedemption.Name = "gbPrizeRedemption"
        Me.gbPrizeRedemption.Size = New System.Drawing.Size(900, 505)
        Me.gbPrizeRedemption.TabIndex = 5
        Me.gbPrizeRedemption.TabStop = False
        Me.gbPrizeRedemption.Text = "Prize Redemption"
        '
        'btnPCancel
        '
        Me.btnPCancel.Image = Global.ombak.My.Resources.Resources.cancelbutton
        Me.btnPCancel.Location = New System.Drawing.Point(626, 455)
        Me.btnPCancel.Name = "btnPCancel"
        Me.btnPCancel.Size = New System.Drawing.Size(100, 50)
        Me.btnPCancel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.btnPCancel.TabIndex = 163
        Me.btnPCancel.TabStop = False
        '
        'btnPRedeem
        '
        Me.btnPRedeem.Image = Global.ombak.My.Resources.Resources.submitbutton
        Me.btnPRedeem.Location = New System.Drawing.Point(520, 455)
        Me.btnPRedeem.Name = "btnPRedeem"
        Me.btnPRedeem.Size = New System.Drawing.Size(100, 50)
        Me.btnPRedeem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.btnPRedeem.TabIndex = 162
        Me.btnPRedeem.TabStop = False
        '
        'cboxPPrizeAmount
        '
        Me.cboxPPrizeAmount.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboxPPrizeAmount.FormattingEnabled = True
        Me.cboxPPrizeAmount.Items.AddRange(New Object() {"1", "2", "3", "4", "5"})
        Me.cboxPPrizeAmount.Location = New System.Drawing.Point(367, 261)
        Me.cboxPPrizeAmount.Name = "cboxPPrizeAmount"
        Me.cboxPPrizeAmount.Size = New System.Drawing.Size(359, 33)
        Me.cboxPPrizeAmount.TabIndex = 161
        '
        'txtPBalancePoint
        '
        Me.txtPBalancePoint.Enabled = False
        Me.txtPBalancePoint.Location = New System.Drawing.Point(367, 352)
        Me.txtPBalancePoint.Name = "txtPBalancePoint"
        Me.txtPBalancePoint.Size = New System.Drawing.Size(359, 32)
        Me.txtPBalancePoint.TabIndex = 8
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(187, 355)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(165, 26)
        Me.Label31.TabIndex = 160
        Me.Label31.Text = "Balance Point : "
        '
        'cboxPSelectPrize
        '
        Me.cboxPSelectPrize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboxPSelectPrize.FormattingEnabled = True
        Me.cboxPSelectPrize.Items.AddRange(New Object() {"Domino Pizza Voucher RM30", "KFC Voucher RM20", "MCD Voucher RM20", "Parkson Voucher RM10", "Watson Voucher RM10", "Chatime Voucher RM10", ""})
        Me.cboxPSelectPrize.Location = New System.Drawing.Point(367, 169)
        Me.cboxPSelectPrize.Name = "cboxPSelectPrize"
        Me.cboxPSelectPrize.Size = New System.Drawing.Size(359, 33)
        Me.cboxPSelectPrize.TabIndex = 4
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(190, 125)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(162, 26)
        Me.Label34.TabIndex = 158
        Me.Label34.Text = "Point Amount : "
        '
        'txtPSinglePrizePoint
        '
        Me.txtPSinglePrizePoint.Enabled = False
        Me.txtPSinglePrizePoint.Location = New System.Drawing.Point(367, 216)
        Me.txtPSinglePrizePoint.Name = "txtPSinglePrizePoint"
        Me.txtPSinglePrizePoint.Size = New System.Drawing.Size(359, 32)
        Me.txtPSinglePrizePoint.TabIndex = 5
        '
        'cboxPCusID
        '
        Me.cboxPCusID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboxPCusID.FormattingEnabled = True
        Me.cboxPCusID.Location = New System.Drawing.Point(367, 31)
        Me.cboxPCusID.Name = "cboxPCusID"
        Me.cboxPCusID.Size = New System.Drawing.Size(359, 33)
        Me.cboxPCusID.TabIndex = 1
        '
        'txtPTotalPrizePoint
        '
        Me.txtPTotalPrizePoint.Enabled = False
        Me.txtPTotalPrizePoint.Location = New System.Drawing.Point(367, 307)
        Me.txtPTotalPrizePoint.Name = "txtPTotalPrizePoint"
        Me.txtPTotalPrizePoint.Size = New System.Drawing.Size(359, 32)
        Me.txtPTotalPrizePoint.TabIndex = 7
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(205, 173)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(147, 26)
        Me.Label32.TabIndex = 148
        Me.Label32.Text = "Select Prize : "
        '
        'singlepoint
        '
        Me.singlepoint.AutoSize = True
        Me.singlepoint.Location = New System.Drawing.Point(149, 220)
        Me.singlepoint.Name = "singlepoint"
        Me.singlepoint.Size = New System.Drawing.Size(203, 26)
        Me.singlepoint.TabIndex = 142
        Me.singlepoint.Text = "Single Prize Point : "
        '
        'txtPPoint
        '
        Me.txtPPoint.Enabled = False
        Me.txtPPoint.Location = New System.Drawing.Point(367, 122)
        Me.txtPPoint.Name = "txtPPoint"
        Me.txtPPoint.Size = New System.Drawing.Size(359, 32)
        Me.txtPPoint.TabIndex = 3
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(163, 310)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(189, 26)
        Me.Label35.TabIndex = 139
        Me.Label35.Text = "Total Prize Point : "
        '
        'prizeamount
        '
        Me.prizeamount.AutoSize = True
        Me.prizeamount.Location = New System.Drawing.Point(190, 265)
        Me.prizeamount.Name = "prizeamount"
        Me.prizeamount.Size = New System.Drawing.Size(162, 26)
        Me.prizeamount.TabIndex = 138
        Me.prizeamount.Text = "Prize Amount : "
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(162, 79)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(190, 26)
        Me.Label37.TabIndex = 135
        Me.Label37.Text = "Customer Name : "
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(199, 34)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(153, 26)
        Me.Label38.TabIndex = 134
        Me.Label38.Text = "Customer ID : "
        '
        'txtPCusName
        '
        Me.txtPCusName.Enabled = False
        Me.txtPCusName.Location = New System.Drawing.Point(367, 76)
        Me.txtPCusName.Name = "txtPCusName"
        Me.txtPCusName.Size = New System.Drawing.Size(359, 32)
        Me.txtPCusName.TabIndex = 2
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.gbViewRedemption)
        Me.TabPage1.Location = New System.Drawing.Point(4, 34)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1342, 535)
        Me.TabPage1.TabIndex = 5
        Me.TabPage1.Text = "View Redemption"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'gbViewRedemption
        '
        Me.gbViewRedemption.Controls.Add(Me.btnRCancel)
        Me.gbViewRedemption.Controls.Add(Me.txtRPrizeAmount)
        Me.gbViewRedemption.Controls.Add(Me.txtRPrizeName)
        Me.gbViewRedemption.Controls.Add(Me.Label36)
        Me.gbViewRedemption.Controls.Add(Me.txtRPrizePoint)
        Me.gbViewRedemption.Controls.Add(Me.cboxRRedemptionID)
        Me.gbViewRedemption.Controls.Add(Me.txtRTotalPrizePoint)
        Me.gbViewRedemption.Controls.Add(Me.Label39)
        Me.gbViewRedemption.Controls.Add(Me.Label40)
        Me.gbViewRedemption.Controls.Add(Me.txtRCustomerName)
        Me.gbViewRedemption.Controls.Add(Me.Label41)
        Me.gbViewRedemption.Controls.Add(Me.Label42)
        Me.gbViewRedemption.Controls.Add(Me.Label43)
        Me.gbViewRedemption.Controls.Add(Me.Label44)
        Me.gbViewRedemption.Controls.Add(Me.txtRCustomerID)
        Me.gbViewRedemption.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.gbViewRedemption.Location = New System.Drawing.Point(221, 15)
        Me.gbViewRedemption.Name = "gbViewRedemption"
        Me.gbViewRedemption.Size = New System.Drawing.Size(900, 505)
        Me.gbViewRedemption.TabIndex = 6
        Me.gbViewRedemption.TabStop = False
        Me.gbViewRedemption.Text = "View Redemption"
        '
        'btnRCancel
        '
        Me.btnRCancel.Image = Global.ombak.My.Resources.Resources.cancelbutton
        Me.btnRCancel.Location = New System.Drawing.Point(625, 455)
        Me.btnRCancel.Name = "btnRCancel"
        Me.btnRCancel.Size = New System.Drawing.Size(100, 50)
        Me.btnRCancel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.btnRCancel.TabIndex = 164
        Me.btnRCancel.TabStop = False
        '
        'txtRPrizeAmount
        '
        Me.txtRPrizeAmount.Enabled = False
        Me.txtRPrizeAmount.Location = New System.Drawing.Point(366, 267)
        Me.txtRPrizeAmount.Name = "txtRPrizeAmount"
        Me.txtRPrizeAmount.Size = New System.Drawing.Size(359, 32)
        Me.txtRPrizeAmount.TabIndex = 6
        '
        'txtRPrizeName
        '
        Me.txtRPrizeName.Enabled = False
        Me.txtRPrizeName.Location = New System.Drawing.Point(366, 175)
        Me.txtRPrizeName.Name = "txtRPrizeName"
        Me.txtRPrizeName.Size = New System.Drawing.Size(359, 32)
        Me.txtRPrizeName.TabIndex = 4
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(161, 130)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(190, 26)
        Me.Label36.TabIndex = 158
        Me.Label36.Text = "Customer Name : "
        '
        'txtRPrizePoint
        '
        Me.txtRPrizePoint.Enabled = False
        Me.txtRPrizePoint.Location = New System.Drawing.Point(366, 222)
        Me.txtRPrizePoint.Name = "txtRPrizePoint"
        Me.txtRPrizePoint.Size = New System.Drawing.Size(359, 32)
        Me.txtRPrizePoint.TabIndex = 5
        '
        'cboxRRedemptionID
        '
        Me.cboxRRedemptionID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboxRRedemptionID.FormattingEnabled = True
        Me.cboxRRedemptionID.Location = New System.Drawing.Point(366, 36)
        Me.cboxRRedemptionID.Name = "cboxRRedemptionID"
        Me.cboxRRedemptionID.Size = New System.Drawing.Size(359, 33)
        Me.cboxRRedemptionID.TabIndex = 1
        '
        'txtRTotalPrizePoint
        '
        Me.txtRTotalPrizePoint.Enabled = False
        Me.txtRTotalPrizePoint.Location = New System.Drawing.Point(366, 312)
        Me.txtRTotalPrizePoint.Name = "txtRTotalPrizePoint"
        Me.txtRTotalPrizePoint.Size = New System.Drawing.Size(359, 32)
        Me.txtRTotalPrizePoint.TabIndex = 7
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(204, 178)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(145, 26)
        Me.Label39.TabIndex = 148
        Me.Label39.Text = "Prize Name : "
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(213, 225)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(136, 26)
        Me.Label40.TabIndex = 142
        Me.Label40.Text = "Prize Point : "
        '
        'txtRCustomerName
        '
        Me.txtRCustomerName.Enabled = False
        Me.txtRCustomerName.Location = New System.Drawing.Point(366, 127)
        Me.txtRCustomerName.Name = "txtRCustomerName"
        Me.txtRCustomerName.Size = New System.Drawing.Size(359, 32)
        Me.txtRCustomerName.TabIndex = 3
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(162, 315)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(189, 26)
        Me.Label41.TabIndex = 139
        Me.Label41.Text = "Total Prize Point : "
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(189, 270)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(162, 26)
        Me.Label42.TabIndex = 138
        Me.Label42.Text = "Prize Amount : "
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(198, 84)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(153, 26)
        Me.Label43.TabIndex = 135
        Me.Label43.Text = "Customer ID : "
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(175, 39)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(176, 26)
        Me.Label44.TabIndex = 134
        Me.Label44.Text = "Redemption ID : "
        '
        'txtRCustomerID
        '
        Me.txtRCustomerID.Enabled = False
        Me.txtRCustomerID.Location = New System.Drawing.Point(366, 81)
        Me.txtRCustomerID.Name = "txtRCustomerID"
        Me.txtRCustomerID.Size = New System.Drawing.Size(359, 32)
        Me.txtRCustomerID.TabIndex = 2
        '
        'lblStaffName
        '
        Me.lblStaffName.AutoSize = True
        Me.lblStaffName.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.lblStaffName.Location = New System.Drawing.Point(1120, 112)
        Me.lblStaffName.Name = "lblStaffName"
        Me.lblStaffName.Size = New System.Drawing.Size(0, 29)
        Me.lblStaffName.TabIndex = 91
        '
        'lblStaffID
        '
        Me.lblStaffID.AutoSize = True
        Me.lblStaffID.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.lblStaffID.Location = New System.Drawing.Point(1120, 64)
        Me.lblStaffID.Name = "lblStaffID"
        Me.lblStaffID.Size = New System.Drawing.Size(0, 29)
        Me.lblStaffID.TabIndex = 89
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label45.Location = New System.Drawing.Point(953, 112)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(149, 29)
        Me.Label45.TabIndex = 87
        Me.Label45.Text = "Staff Name : "
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label46.Location = New System.Drawing.Point(995, 64)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(107, 29)
        Me.Label46.TabIndex = 86
        Me.Label46.Text = "Staff ID : "
        '
        'backButton
        '
        Me.backButton.Image = CType(resources.GetObject("backButton.Image"), System.Drawing.Image)
        Me.backButton.Location = New System.Drawing.Point(12, 10)
        Me.backButton.Name = "backButton"
        Me.backButton.Size = New System.Drawing.Size(110, 65)
        Me.backButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.backButton.TabIndex = 72
        Me.backButton.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.ombak.My.Resources.Resources.logo
        Me.PictureBox1.Location = New System.Drawing.Point(425, 10)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(500, 150)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 68
        Me.PictureBox1.TabStop = False
        '
        'Customer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1350, 733)
        Me.Controls.Add(Me.lblStaffName)
        Me.Controls.Add(Me.lblStaffID)
        Me.Controls.Add(Me.Label45)
        Me.Controls.Add(Me.Label46)
        Me.Controls.Add(Me.backButton)
        Me.Controls.Add(Me.TabControl)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Customer"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "Customer"
        Me.TabControl.ResumeLayout(False)
        Me.TapPage1.ResumeLayout(False)
        Me.gbAddCustomer.ResumeLayout(False)
        Me.gbAddCustomer.PerformLayout()
        CType(Me.btnAAdd, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnACancel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.gbViewCustomer.ResumeLayout(False)
        Me.gbViewCustomer.PerformLayout()
        CType(Me.btnVCancel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.gbEditCustomer.ResumeLayout(False)
        Me.gbEditCustomer.PerformLayout()
        CType(Me.btnECancel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnEUpdate, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        Me.gbDeleteCustomer.ResumeLayout(False)
        Me.gbDeleteCustomer.PerformLayout()
        CType(Me.btnDCancel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnDDelete, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        Me.gbPrizeRedemption.ResumeLayout(False)
        Me.gbPrizeRedemption.PerformLayout()
        CType(Me.btnPCancel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnPRedeem, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage1.ResumeLayout(False)
        Me.gbViewRedemption.ResumeLayout(False)
        Me.gbViewRedemption.PerformLayout()
        CType(Me.btnRCancel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.backButton, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents TabControl As System.Windows.Forms.TabControl
    Friend WithEvents TapPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents gbViewCustomer As System.Windows.Forms.GroupBox
    Friend WithEvents gbEditCustomer As System.Windows.Forms.GroupBox
    Friend WithEvents txtEPoint As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtEHomeAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtEContact As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtEEmail As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txtECustomerIC As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtECusName As System.Windows.Forms.TextBox
    Friend WithEvents cboxECusID As System.Windows.Forms.ComboBox
    Friend WithEvents txtEGender As System.Windows.Forms.TextBox
    Friend WithEvents gbDeleteCustomer As System.Windows.Forms.GroupBox
    Friend WithEvents txtDGender As System.Windows.Forms.TextBox
    Friend WithEvents cboxDCusID As System.Windows.Forms.ComboBox
    Friend WithEvents txtDPoint As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents txtDHomeAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtDContact As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents txtDEmail As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents txtDCustomerIC As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents txtDCusName As System.Windows.Forms.TextBox
    Friend WithEvents gbPrizeRedemption As System.Windows.Forms.GroupBox
    Friend WithEvents txtPSinglePrizePoint As System.Windows.Forms.TextBox
    Friend WithEvents cboxPCusID As System.Windows.Forms.ComboBox
    Friend WithEvents txtPTotalPrizePoint As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents singlepoint As System.Windows.Forms.Label
    Friend WithEvents txtPPoint As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents prizeamount As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents txtPCusName As System.Windows.Forms.TextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents cboxPSelectPrize As System.Windows.Forms.ComboBox
    Friend WithEvents txtPBalancePoint As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents gbAddCustomer As System.Windows.Forms.GroupBox
    Friend WithEvents txtAHomeAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtAContact As System.Windows.Forms.TextBox
    Friend WithEvents contact As System.Windows.Forms.Label
    Friend WithEvents cboxAEmail2 As System.Windows.Forms.ComboBox
    Friend WithEvents txtAEmail1 As System.Windows.Forms.TextBox
    Friend WithEvents rbAFemale As System.Windows.Forms.RadioButton
    Friend WithEvents rbAMale As System.Windows.Forms.RadioButton
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtACustomerIC As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtACusName As System.Windows.Forms.TextBox
    Friend WithEvents txtACusID As System.Windows.Forms.TextBox
    Friend WithEvents txtVGender As System.Windows.Forms.TextBox
    Friend WithEvents cboxVCusID As System.Windows.Forms.ComboBox
    Friend WithEvents txtVPoint As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtVHomeAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtVContact As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtVEmail As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtVCustomerIC As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtVCusName As System.Windows.Forms.TextBox
    Friend WithEvents cboxPPrizeAmount As System.Windows.Forms.ComboBox
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents gbViewRedemption As System.Windows.Forms.GroupBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents txtRPrizePoint As System.Windows.Forms.TextBox
    Friend WithEvents cboxRRedemptionID As System.Windows.Forms.ComboBox
    Friend WithEvents txtRTotalPrizePoint As System.Windows.Forms.TextBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents txtRCustomerName As System.Windows.Forms.TextBox
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents txtRCustomerID As System.Windows.Forms.TextBox
    Friend WithEvents txtRPrizeAmount As System.Windows.Forms.TextBox
    Friend WithEvents txtRPrizeName As System.Windows.Forms.TextBox
    Friend WithEvents backButton As System.Windows.Forms.PictureBox
    Friend WithEvents btnAAdd As System.Windows.Forms.PictureBox
    Friend WithEvents btnACancel As System.Windows.Forms.PictureBox
    Friend WithEvents btnVCancel As System.Windows.Forms.PictureBox
    Friend WithEvents btnEUpdate As System.Windows.Forms.PictureBox
    Friend WithEvents btnDDelete As System.Windows.Forms.PictureBox
    Friend WithEvents btnPRedeem As System.Windows.Forms.PictureBox
    Friend WithEvents btnECancel As System.Windows.Forms.PictureBox
    Friend WithEvents btnDCancel As System.Windows.Forms.PictureBox
    Friend WithEvents btnPCancel As System.Windows.Forms.PictureBox
    Friend WithEvents btnRCancel As System.Windows.Forms.PictureBox
    Friend WithEvents lblStaffName As System.Windows.Forms.Label
    Friend WithEvents lblStaffID As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
End Class
